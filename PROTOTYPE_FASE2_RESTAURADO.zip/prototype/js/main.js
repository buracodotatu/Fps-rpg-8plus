/* ============================================================
 * main.js - orquestrador do protótipo de validação.
 * Não faz parte do DOOMED original; escrito para este teste.
 *
 * CORREÇÃO v0.2:
 *   - separa realDt (FPS/window) de simDt (simulação, clamp 0,05s)
 *   - FPS calculado sobre tempo real entre frames
 *   - FPS mínimo = menor média de janela de 0,5s (não frame individual)
 *   - ativa F.touch.setActive(true) no onBootTap
 * ============================================================ */
(function () {
  'use strict';

  var F = window.FPS;
  var fb = F.fb;
  var ray = F.raycaster;
  var player = F.player;
  var level = F.level;
  var IN = F.input;

  var canvas = null;
  var bootOverlay = null;
  var hudFps, hudMin, hudRender, hudRes;
  var resBtns = [];

  /* ---- métricas ---- */
  var lastTime = 0;
  var fpsTimer = 0, fpsFrames = 0;
  var minFps = Infinity;
  var renderSum = 0, renderN = 0;
  var running = false;

  /* ---- sprites estáticos ---- */
  var sprites = [
    { x: 5.5,  y: 3.5,  frame: F.art.props.medkit, scale: 0.35, vOff: 0, shade: 0 },
    { x: 8.5,  y: 6.5,  frame: F.art.props.ammo,   scale: 0.30, vOff: 0, shade: 0 },
    { x: 12.5, y: 10.5, frame: F.art.props.medkit, scale: 0.35, vOff: 0, shade: 0 },
    { x: 3.5,  y: 12.5, frame: F.art.props.ammo,   scale: 0.30, vOff: 0, shade: 0 }
  ];

  var currentW = 480, currentH = 270;

  function init() {
    canvas       = document.getElementById('screen');
    bootOverlay  = document.getElementById('boot-overlay');
    hudFps       = document.getElementById('hud-fps');
    hudMin       = document.getElementById('hud-min');
    hudRender    = document.getElementById('hud-render');
    hudRes       = document.getElementById('hud-res');

    if (!canvas) return;

    IN.attach(canvas);
    F.touch.attach(document.getElementById('game'));

    fb.create(canvas, currentW, currentH);
    player.reset();

    resBtns = Array.prototype.slice.call(document.querySelectorAll('.res-btn'));
    resBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        setResolution(parseInt(btn.dataset.w, 10), parseInt(btn.dataset.h, 10));
      });
    });
    updateResButtons();

    bootOverlay.addEventListener('touchstart', onBootTap, { passive: false });
    bootOverlay.addEventListener('click', onBootTap, false);

    window.addEventListener('resize', onResize, false);
    window.addEventListener('orientationchange', function () {
      setTimeout(onResize, 120); setTimeout(onResize, 450);
    }, false);

    requestAnimationFrame(frame);
  }

  function onBootTap(e) {
    if (e.cancelable) e.preventDefault();
    if (running) return;
    running = true;
    bootOverlay.classList.add('hidden');
    if (F.touch && F.touch.setActive) F.touch.setActive(true);
    onResize();
  }

  function setResolution(w, h) {
    currentW = w; currentH = h;
    fb.resize(w, h);
    ray.prepare(fb);
    player.horizon = fb.h * 0.5 + player.pitch * fb.h;
    hudRes.textContent = w + '×' + h;
    updateResButtons();
  }

  function updateResButtons() {
    resBtns.forEach(function (btn) {
      var on = (parseInt(btn.dataset.w, 10) === currentW);
      btn.classList.toggle('on', on);
    });
  }

  function onResize() {
    ray.prepare(fb);
  }

  function frame(now) {
    requestAnimationFrame(frame);

    if (!running) {
      lastTime = now;
      return;
    }

    if (!lastTime) lastTime = now;

    /* realDt = tempo real entre frames; simDt = clampado para física */
    var realDt = (now - lastTime) / 1000;
    lastTime = now;
    if (realDt < 0) realDt = 0;
    var simDt = realDt > 0.05 ? 0.05 : realDt;

    /* ---- simulação ---- */
    player.update(simDt, level);

    /* ---- render (tempo medido inclui fb.present) ---- */
    var t0 = performance.now();
    fb.clear(0xFF000000);
    ray.render(fb, level, player, sprites, sprites.length);
    fb.present();
    var t1 = performance.now();

    renderSum += (t1 - t0);
    renderN++;

    /* ---- métricas: FPS sobre realDt ---- */
    fpsTimer += realDt;
    fpsFrames++;

    if (fpsTimer >= 0.5) {
      var fps = Math.round(fpsFrames / fpsTimer);
      hudFps.textContent = fps + ' FPS';
      if (fps < minFps) {
        minFps = fps;
        /* Documentado como MENOR MÉDIA de janela de 0,5s, não frame individual. */
        hudMin.textContent = 'min ' + minFps;
      }
      fpsTimer = 0;
      fpsFrames = 0;

      if (renderN > 0) {
        hudRender.textContent = 'render ' + (renderSum / renderN).toFixed(2) + ' ms';
        renderSum = 0;
        renderN = 0;
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, false);
  } else {
    init();
  }
})();