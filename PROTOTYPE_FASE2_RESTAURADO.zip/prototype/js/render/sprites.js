/* ============================================================
 * sprites.js - procedural pixel art + billboard renderer.
 *
 *  1. SpriteCanvas: a tiny paint surface of palette indices where
 *     index 0 means "transparent".  Enemies, pickups, projectiles
 *     and the first-person weapons are all drawn with it at boot
 *     (ellipse / line / tri primitives + an auto-outline pass),
 *     so there are zero image assets.
 *
 *  2. drawSprite(): classic billboard projection with per-column
 *     z-buffer tests, so sprites are correctly eaten by walls.
 * ============================================================ */
(function (F) {
  'use strict';

  var P = F.palette, R = P.RAMPS, B = P.BRIGHT;

  /* ------------------------------------------------ SpriteCanvas */
  function SC(w, h) { this.w = w; this.h = h; this.d = new Uint8Array(w * h); }

  SC.prototype.set = function (x, y, c) {
    x |= 0; y |= 0;
    if (x < 0 || y < 0 || x >= this.w || y >= this.h || !c) return;
    this.d[y * this.w + x] = c;
  };
  SC.prototype.get = function (x, y) {
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return 0;
    return this.d[y * this.w + x];
  };
  SC.prototype.rect = function (x, y, w, h, c) {
    for (var j = 0; j < h; j++) for (var i = 0; i < w; i++) this.set(x + i, y + j, c);
  };
  SC.prototype.frame = function (x, y, w, h, c) {
    for (var i = 0; i < w; i++) { this.set(x + i, y, c); this.set(x + i, y + h - 1, c); }
    for (var j = 0; j < h; j++) { this.set(x, y + j, c); this.set(x + w - 1, y + j, c); }
  };
  SC.prototype.ellipse = function (cx, cy, rx, ry, c) {
    for (var y = -ry; y <= ry; y++) {
      var w = Math.floor(rx * Math.sqrt(Math.max(0, 1 - (y * y) / (ry * ry))));
      for (var x = -w; x <= w; x++) this.set(cx + x, cy + y, c);
    }
  };
  SC.prototype.line = function (x0, y0, x1, y1, wd, c) {
    var dx = x1 - x0, dy = y1 - y0, n = Math.max(Math.abs(dx), Math.abs(dy));
    if (n === 0) { this.rect(x0, y0, wd, wd, c); return; }
    for (var i = 0; i <= n; i++) {
      var x = Math.round(x0 + dx * i / n), y = Math.round(y0 + dy * i / n);
      var r = (wd - 1) >> 1;
      this.rect(x - r, y - r, wd, wd, c);
    }
  };
  SC.prototype.tri = function (x0, y0, x1, y1, x2, y2, c) {
    var minx = Math.min(x0, x1, x2), maxx = Math.max(x0, x1, x2);
    var miny = Math.min(y0, y1, y2), maxy = Math.max(y0, y1, y2);
    function sign(ax, ay, bx, by, px, py) { return (ax - bx) * (py - by) - (px - bx) * (ay - by); }
    for (var y = miny; y <= maxy; y++) for (var x = minx; x <= maxx; x++) {
      var d1 = sign(x0, y0, x1, y1, x, y), d2 = sign(x1, y1, x2, y2, x, y), d3 = sign(x2, y2, x0, y0, x, y);
      var neg = (d1 < 0) || (d2 < 0) || (d3 < 0), pos = (d1 > 0) || (d2 > 0) || (d3 > 0);
      if (!(neg && pos)) this.set(x, y, c);
    }
  };
  /* darken the silhouette edge: makes procedural blobs read as art */
  SC.prototype.outline = function (c, alphaish) {
    var out = new Uint8Array(this.d);
    for (var y = 0; y < this.h; y++) for (var x = 0; x < this.w; x++) {
      if (out[y * this.w + x]) continue;
      var n = 0;
      if (this.get(x - 1, y)) n++; if (this.get(x + 1, y)) n++;
      if (this.get(x, y - 1)) n++; if (this.get(x, y + 1)) n++;
      if (n) out[y * this.w + x] = c;
    }
    this.d = out;
    return this;
  };
  SC.prototype.clone = function () {
    var s = new SC(this.w, this.h); s.d.set(this.d); return s;
  };
  SC.prototype.offset = function (dx, dy) {
    var s = new SC(this.w, this.h);
    for (var y = 0; y < this.h; y++) for (var x = 0; x < this.w; x++) {
      var c = this.get(x, y); if (c) s.set(x + dx, y + dy, c);
    }
    return s;
  };
  /* vertical squash / stretch around the feet - used for death anims */
  SC.prototype.squash = function (sy, sx) {
    var s = new SC(this.w, this.h);
    var cy = this.h - 1;
    for (var y = 0; y < this.h; y++) for (var x = 0; x < this.w; x++) {
      var srcY = Math.round(cy - (cy - y) / sy);
      var srcX = Math.round(this.w / 2 + (x - this.w / 2) / sx);
      var c = this.get(srcX, srcY); if (c) s.set(x, y, c);
    }
    return s;
  };
  SC.prototype.remap = function (map) {
    for (var i = 0; i < this.d.length; i++) { var c = this.d[i]; if (c && map[c] !== undefined) this.d[i] = map[c]; }
    return this;
  };
  SC.prototype.flipX = function () {
    var s = new SC(this.w, this.h);
    for (var y = 0; y < this.h; y++) for (var x = 0; x < this.w; x++) s.set(x, y, this.get(this.w - 1 - x, y));
    return s;
  };
  SC.prototype.frame32 = function () {
    return { w: this.w, h: this.h, d: this.d };
  };

  /* ------------------------------------------------ enemy: imp */
  function impBase(legs, armsUp, jaw) {
    var s = new SC(40, 46);
    var body = R.DEMON.i(0.62), dark = R.DEMON.i(0.3), light = R.DEMON.i(0.86);
    var belly = R.DEMON2.i(0.55);

    /* legs (shamble) */
    var fL = 14 + legs * 3, fR = 26 - legs * 3;
    s.line(17, 33, fL, 44, 4, dark);
    s.line(23, 33, fR, 44, 4, dark);
    s.ellipse(fL, 44, 3, 2, dark); s.ellipse(fR, 44, 3, 2, dark);
    s.set(fL - 2, 45, R.BONE.i(0.4)); s.set(fR + 2, 45, R.BONE.i(0.4));

    /* torso */
    s.ellipse(20, 28, 8, 9, body);
    s.ellipse(20, 30, 5, 6, belly);
    s.ellipse(20, 24, 8, 4, light);

    /* arms */
    var hy = armsUp ? 15 : 32, hx1 = armsUp ? 5 : 6, hx2 = armsUp ? 35 : 34;
    s.line(13, 23, hx1, hy, 3, body);
    s.line(27, 23, hx2, hy, 3, body);
    s.ellipse(hx1, hy, 2, 2, dark); s.ellipse(hx2, hy, 2, 2, dark);
    for (var k = -1; k <= 1; k++) {
      s.line(hx1, hy + 1, hx1 + k * 2, hy + 4, 1, R.BONE.i(0.95));
      s.line(hx2, hy + 1, hx2 + k * 2, hy + 4, 1, R.BONE.i(0.95));
    }

    /* head + horns */
    s.ellipse(20, 13, 10, 9, body);
    s.ellipse(20, 11, 8, 6, light);
    s.tri(12, 8, 7, 1, 14, 6, R.BONE.i(0.7));
    s.tri(28, 8, 33, 1, 26, 6, R.BONE.i(0.7));

    /* brow ridge, eyes, mouth */
    s.rect(11, 11, 18, 2, dark);
    s.ellipse(15, 13, 2, 2, B.YELLOW); s.ellipse(25, 13, 2, 2, B.YELLOW);
    s.set(15, 13, B.RED); s.set(25, 13, B.RED);
    var mh = jaw ? 5 : 2;
    s.rect(14, 17, 12, mh, R.BLOOD.i(0.35));
    if (jaw) s.rect(15, 18, 10, 3, R.BLOOD.i(0.9));
    for (var t = 0; t < 5; t++) {
      s.set(15 + t * 2, 17, R.BONE.i(0.95));
      if (jaw) s.set(15 + t * 2, 21, R.BONE.i(0.8));
    }
    /* spines */
    for (var i2 = 0; i2 < 4; i2++) s.set(20 + (i2 - 1.5) * 3, 4 + Math.abs(i2 - 1.5), R.DEMON.i(0.25));
    return s;
  }

  /* ------------------------------------------------ enemy: dead soldier */
  function soldierBase(legs, fire) {
    var s = new SC(30, 46);
    var uni = R.UNIFORM.i(0.55), dark = R.UNIFORM.i(0.28), lite = R.UNIFORM.i(0.8);
    var sk = R.SKIN.i(0.55), skd = R.SKIN.i(0.3);

    s.line(13, 34, 11 + legs * 2, 44, 4, dark);
    s.line(17, 34, 19 - legs * 2, 44, 4, dark);
    s.ellipse(11 + legs * 2, 44, 3, 2, R.BLACK.i(0.1));
    s.ellipse(19 - legs * 2, 44, 3, 2, R.BLACK.i(0.1));

    s.rect(9, 20, 12, 15, uni);
    s.rect(9, 20, 12, 3, lite);
    s.rect(11, 24, 8, 3, dark);            /* webbing */
    s.rect(13, 27, 4, 6, dark);

    /* head + helmet */
    s.ellipse(15, 14, 5, 5, sk);
    s.rect(11, 15, 8, 2, skd);
    s.ellipse(15, 10, 6, 4, dark);
    s.rect(9, 12, 12, 2, dark);
    s.set(13, 14, B.RED); s.set(17, 14, B.RED);   /* zombie glow eyes */

    /* rifle */
    var gy = fire ? 19 : 24;
    s.line(6, gy, 24, gy - 1, 2, R.BLACK.i(0.18));
    s.line(9, gy + 1, 14, gy + 3, 2, R.STEEL.i(0.35));
    s.line(12, 22, 9, gy, 3, sk);
    s.line(18, 22, 21, gy, 3, sk);
    if (fire) {
      s.ellipse(26, gy - 1, 4, 3, B.YELLOW);
      s.ellipse(26, gy - 1, 2, 2, B.WHITE);
      s.set(30, gy - 1, B.ORANGE);
    }
    return s;
  }

  /* ------------------------------------------------ enemy: floating cacodemon */
  function cacoBase(mouth, charge) {
    var s = new SC(46, 40);
    var body = R.DEMON.i(0.6), dark = R.DEMON.i(0.28), lite = R.DEMON.i(0.9);

    s.ellipse(23, 20, 17, 15, body);
    s.ellipse(18, 13, 9, 6, lite);
    s.ellipse(23, 26, 12, 8, dark);

    /* crown spikes */
    for (var i = 0; i < 5; i++) {
      var a = -0.9 + i * 0.45, cx = 23 + Math.sin(a) * 15, cy = 20 - Math.cos(a) * 14;
      s.tri(cx, cy, cx + Math.sin(a) * 6, cy - Math.cos(a) * 7, cx + Math.sin(a + 0.3) * 3, cy - Math.cos(a + 0.3) * 3, R.BONE.i(0.6));
    }

    /* single big eye */
    s.ellipse(23, 13, 7, 6, R.BONE.i(0.98));
    s.ellipse(23, 13, 4, 4, R.GLASS.i(0.9));
    s.ellipse(23, 13, 2, 3, R.BLACK.i(0.02));
    s.set(21, 11, B.WHITE);

    /* toothed maw */
    var mh = mouth ? 9 : 4;
    s.ellipse(23, 27, 11, mh, R.BLOOD.i(0.22));
    if (mouth) s.ellipse(23, 28, 8, 6, R.BLOOD.i(0.85));
    for (var t = 0; t < 9; t++) {
      var tx = 13 + t * 2.5;
      s.set(tx, 27 - mh + 1, R.BONE.i(0.95)); s.set(tx, 27 - mh + 2, R.BONE.i(0.85));
      s.set(tx, 27 + mh - 1, R.BONE.i(0.9));
      if (mouth) s.set(tx, 27 + mh - 2, R.BONE.i(0.75));
    }
    if (charge) {
      s.ellipse(23, 30, 5, 4, B.ORANGE);
      s.ellipse(23, 30, 3, 2, B.YELLOW);
      s.ellipse(23, 30, 1, 1, B.WHITE);
    }
    return s;
  }

  /* ------------------------------------------------ build frame sets */
  function buildEnemyFrames() {
    var sets = {};

    /* imp: 4-frame shamble, claw swipe, flinch, 3-frame gib */
    var impIdle = impBase(0, false, false);
    sets.imp = {
      walk: [
        impBase(0, false, false).outline(R.BLACK.i(0.02)).frame32(),
        impBase(1, false, false).offset(0, 1).outline(R.BLACK.i(0.02)).frame32(),
        impBase(2, false, false).offset(0, 2).outline(R.BLACK.i(0.02)).frame32(),
        impBase(1, false, false).offset(0, 1).outline(R.BLACK.i(0.02)).frame32()
      ],
      attack: impBase(1, true, true).offset(0, -1).outline(R.BLACK.i(0.02)).frame32(),
      pain: impBase(0, false, true).offset(1, -1).outline(R.BLACK.i(0.02)).frame32(),
      die: [
        impIdle.clone().outline(R.BLACK.i(0.02)).squash(0.66, 1.12).frame32(),
        impIdle.clone().outline(R.BLACK.i(0.02)).squash(0.38, 1.3).frame32(),
        (function () {
          var s = impIdle.clone().squash(0.2, 1.45);
          s.ellipse(20, 44, 15, 3, R.BLOOD.i(0.55));
          s.ellipse(14, 43, 5, 2, R.BLOOD.i(0.8));
          return s.outline(R.BLACK.i(0.02)).frame32();
        })()
      ]
    };

    /* soldier: march, rifle burst, flinch, gib */
    sets.soldier = {
      walk: [
        soldierBase(0, false).outline(R.BLACK.i(0.02)).frame32(),
        soldierBase(1, false).offset(0, 1).outline(R.BLACK.i(0.02)).frame32(),
        soldierBase(2, false).offset(0, 1).outline(R.BLACK.i(0.02)).frame32(),
        soldierBase(1, false).outline(R.BLACK.i(0.02)).frame32()
      ],
      attack: soldierBase(0, true).outline(R.BLACK.i(0.02)).frame32(),
      pain: soldierBase(0, false).offset(-1, -1).outline(R.BLACK.i(0.02)).frame32(),
      die: [
        soldierBase(0, false).clone().outline(R.BLACK.i(0.02)).squash(0.6, 1.1).frame32(),
        soldierBase(0, false).clone().outline(R.BLACK.i(0.02)).squash(0.34, 1.28).frame32(),
        (function () {
          var s = soldierBase(0, false).clone().squash(0.18, 1.4);
          s.ellipse(15, 44, 13, 3, R.BLOOD.i(0.6));
          return s.outline(R.BLACK.i(0.02)).frame32();
        })()
      ]
    };

    /* caco: hover, maw open, flinch, squish */
    sets.caco = {
      walk: [
        cacoBase(false, false).outline(R.BLACK.i(0.02)).frame32(),
        cacoBase(false, false).clone().offset(0, 1).outline(R.BLACK.i(0.02)).frame32(),
        cacoBase(true, false).outline(R.BLACK.i(0.02)).frame32(),
        cacoBase(false, false).clone().offset(0, -1).outline(R.BLACK.i(0.02)).frame32()
      ],
      attack: cacoBase(true, true).outline(R.BLACK.i(0.02)).frame32(),
      pain: cacoBase(true, false).clone().offset(1, -1).outline(R.BLACK.i(0.02)).frame32(),
      die: [
        cacoBase(true, false).clone().squash(0.62, 1.2).frame32(),
        cacoBase(true, false).clone().squash(0.36, 1.42).frame32(),
        (function () {
          var s = cacoBase(true, false).clone().squash(0.16, 1.5);
          s.ellipse(23, 38, 18, 3, R.BLOOD.i(0.7));
          return s.outline(R.BLACK.i(0.02)).frame32();
        })()
      ]
    };
    return sets;
  }

  /* ------------------------------------------------ props & pickups */
  function buildProps() {
    var o = {};

    /* medkit */
    (function () {
      var s = new SC(20, 18);
      s.rect(2, 4, 16, 12, R.BONE.i(0.95));
      s.rect(2, 4, 16, 3, R.BONE.i(0.7));
      s.frame(2, 4, 16, 12, R.BLACK.i(0.1));
      s.rect(9, 6, 3, 9, R.BLOOD.i(0.9));
      s.rect(6, 9, 9, 3, R.BLOOD.i(0.9));
      s.rect(7, 2, 6, 2, R.STEEL.i(0.5));
      o.medkit = s.outline(R.BLACK.i(0.02)).frame32();
    })();
    /* ammo box */
    (function () {
      var s = new SC(20, 18);
      s.rect(2, 5, 16, 11, R.UNIFORM.i(0.5));
      s.rect(2, 5, 16, 3, R.UNIFORM.i(0.75));
      s.frame(2, 5, 16, 11, R.BLACK.i(0.12));
      for (var i = 0; i < 4; i++) { s.rect(4 + i * 4, 9, 2, 5, R.DEMON2.i(0.85)); s.set(4 + i * 4, 9, B.AMBER); }
      s.rect(8, 3, 4, 2, R.STEEL.i(0.6));
      o.ammo = s.outline(R.BLACK.i(0.02)).frame32();
    })();
    /* armour */
    (function () {
      var s = new SC(20, 20);
      s.rect(4, 3, 12, 14, R.TECH.i(0.7));
      s.tri(4, 3, 16, 3, 10, 8, R.TECH.i(0.9));
      s.frame(4, 3, 12, 14, R.BLACK.i(0.15));
      s.rect(9, 7, 2, 7, B.LIME);
      s.rect(6, 10, 8, 2, B.LIME);
      o.armor = s.outline(R.BLACK.i(0.02)).frame32();
    })();
    /* key card */
    (function () {
      var s = new SC(14, 20);
      s.rect(3, 3, 8, 14, R.DEMON2.i(0.9));
      s.frame(3, 3, 8, 14, R.BLACK.i(0.15));
      s.rect(5, 5, 4, 4, B.AMBER);
      s.rect(4, 12, 6, 1, R.BLACK.i(0.2));
      s.rect(4, 14, 6, 1, R.BLACK.i(0.2));
      s.rect(5, 1, 4, 2, R.STEEL.i(0.7));
      o.key = s.outline(R.BLACK.i(0.02)).frame32();
    })();
    /* weapon crates: shotgun / chaingun resting on a box */
    function gunCrate(kind) {
      var s = new SC(26, 20);
      s.rect(2, 10, 22, 8, R.CRATE.i(0.55));
      s.frame(2, 10, 22, 8, R.BLACK.i(0.14));
      s.rect(2, 10, 22, 2, R.CRATE.i(0.8));
      if (kind === 'shotgun') {
        s.rect(4, 6, 16, 2, R.STEEL.i(0.6));
        s.rect(4, 4, 12, 2, R.STEEL.i(0.75));
        s.rect(16, 8, 6, 3, R.WOOD.i(0.5));
      } else {
        s.rect(5, 5, 14, 3, R.STEEL.i(0.55));
        for (var i = 0; i < 3; i++) s.rect(6 + i * 4, 3, 2, 3, R.STEEL.i(0.8));
        s.rect(18, 7, 5, 4, R.TECH.i(0.6));
        s.set(20, 8, B.AMBER);
      }
      return s.outline(R.BLACK.i(0.02)).frame32();
    }
    o.shotgun = gunCrate('shotgun');
    o.chaingun = gunCrate('chaingun');
    /* fireball (4 spin frames) */
    o.fire = [];
    for (var f = 0; f < 4; f++) {
      var s = new SC(18, 18);
      for (var y = 0; y < 18; y++) for (var x = 0; x < 18; x++) {
        var dx = x - 8.5, dy = y - 8.5, d = Math.sqrt(dx * dx + dy * dy);
        var wob = 1 + 0.28 * Math.sin(Math.atan2(dy, dx) * 3 + f * 1.6);
        if (d < 3.4 * wob) s.set(x, y, B.WHITE);
        else if (d < 5.2 * wob) s.set(x, y, B.YELLOW);
        else if (d < 7 * wob) s.set(x, y, B.ORANGE);
        else if (d < 8.4 * wob) s.set(x, y, R.DEMON.i(0.85));
      }
      o.fire.push(s.frame32());
    }
    /* impact flash */
    o.flash = (function () {
      var s = new SC(20, 20);
      for (var y = 0; y < 20; y++) for (var x = 0; x < 20; x++) {
        var dx = x - 9.5, dy = y - 9.5, d = Math.sqrt(dx * dx + dy * dy);
        if (d < 3) s.set(x, y, B.WHITE);
        else if (d < 6) s.set(x, y, B.EMBER);
        else if (d < 9) s.set(x, y, B.ORANGE);
      }
      return s.frame32();
    })();
    /* spawn portal */
    o.portal = [];
    for (var g = 0; g < 3; g++) {
      var q = new SC(28, 34);
      for (var yy = 0; yy < 34; yy++) for (var xx = 0; xx < 28; xx++) {
        var ddx = (xx - 13.5) / (4 + g * 2), ddy = (yy - 17) / (9 + g * 2);
        var dd = Math.sqrt(ddx * ddx + ddy * ddy);
        if (dd < 0.55) q.set(xx, yy, B.WHITE);
        else if (dd < 0.8) q.set(xx, yy, B.PLASMA);
        else if (dd < 1.05) q.set(xx, yy, R.PURPLE.i(0.8));
        else if (dd < 1.25) q.set(xx, yy, R.PURPLE.i(0.45));
      }
      o.portal.push(q.frame32());
    }
    return o;
  }

  /* ------------------------------------------------ first-person weapons
     All three are drawn bottom-anchored in a 72x56 box with a declared
     muzzle anchor, so the HUD can pin the flash to the barrel tip.      */
  var HAND_W = 72, HAND_H = 56;
  function arm(s, x, y, len, dir) {
    /* sleeve + forearm + hand, reaching from the bottom corner */
    var sx = dir > 0 ? HAND_W : 0;
    s.line(sx, HAND_H, x, y, 11, R.TECH.i(0.30));          /* sleeve  */
    s.line(sx, HAND_H, x + dir * 2, y + 2, 8, R.SKIN.i(0.42)); /* forearm */
    s.ellipse(x, y, 5, 4, R.SKIN.i(0.58));                  /* knuckles */
    for (var i = -1; i <= 1; i++) s.rect(x + i * 3 - 1, y + 2, 2, 4, R.SKIN.i(0.46));
    s.line(x - 4, y - 3, x + 4, y - 3, 2, R.SKIN.i(0.7));   /* knuckle highlight */
  }

  function buildHands() {
    var o = { muzzle: {} };

    /* ---------------- pistol ---------------- */
    (function () {
      var s = new SC(HAND_W, HAND_H);
      s.rect(28, 6, 8, 16, R.STEEL.i(0.45));            /* slide        */
      s.rect(28, 6, 2, 16, R.STEEL.i(0.8));             /* lit edge     */
      s.rect(34, 6, 2, 16, R.STEEL.i(0.2));             /* shaded edge  */
      s.rect(28, 4, 8, 3, R.BLACK.i(0.12));             /* muzzle opening */
      s.rect(29, 4, 6, 1, R.STEEL.i(0.9));
      s.rect(27, 20, 10, 3, R.STEEL.i(0.6));            /* rear sight   */
      s.rect(26, 23, 11, 7, R.STEEL.i(0.32));           /* frame        */
      s.rect(27, 30, 4, 4, R.STEEL.i(0.5));             /* trigger guard*/
      for (var y = 30; y < 50; y++) {                    /* grip, raked  */
        var off = ((y - 30) * 0.45) | 0;
        s.rect(29 + off, y, 9, 1, ((y - 30) % 4 < 2) ? R.WOOD.i(0.34) : R.WOOD.i(0.24));
      }
      arm(s, 36, 40, 0, 1);
      o.pistol = s.outline(R.BLACK.i(0.06)).frame32();
      o.muzzle.pistol = [32, 5];
    })();

    /* ---------------- shotgun ---------------- */
    (function () {
      var s = new SC(HAND_W, HAND_H);
      s.rect(23, 4, 6, 24, R.STEEL.i(0.42));            /* left barrel  */
      s.rect(31, 4, 6, 24, R.STEEL.i(0.30));            /* right barrel */
      s.rect(23, 4, 2, 24, R.STEEL.i(0.75));
      s.rect(29, 8, 2, 20, R.STEEL.i(0.6));             /* rib          */
      s.rect(23, 3, 6, 3, R.BLACK.i(0.14));             /* muzzles      */
      s.rect(31, 3, 6, 3, R.BLACK.i(0.14));
      s.rect(24, 3, 4, 1, R.STEEL.i(0.9));
      s.rect(32, 3, 4, 1, R.STEEL.i(0.9));
      s.rect(21, 26, 20, 9, R.STEEL.i(0.34));           /* receiver     */
      s.rect(21, 26, 20, 2, R.STEEL.i(0.6));
      s.rect(17, 31, 13, 8, R.WOOD.i(0.46));            /* forend       */
      s.rect(17, 31, 13, 2, R.WOOD.i(0.62));
      for (var y = 35; y < 54; y++) {                    /* stock        */
        var off = ((y - 35) * 0.5) | 0;
        s.rect(36 + off, y, 12, 1, (y % 5 < 2) ? R.WOOD.i(0.5) : R.WOOD.i(0.34));
      }
      s.rect(30, 34, 4, 5, R.STEEL.i(0.55));            /* trigger      */
      arm(s, 22, 38, 0, -1);
      arm(s, 44, 44, 0, 1);
      o.shotgun = s.outline(R.BLACK.i(0.06)).frame32();
      o.muzzle.shotgun = [29, 3];
    })();

    /* ---------------- chaingun ---------------- */
    (function () {
      var s = new SC(HAND_W, HAND_H);
      for (var i = 0; i < 4; i++) {                      /* barrel cluster */
        var x = 19 + i * 5;
        s.rect(x, 6, 4, 18, (i % 2) ? R.STEEL.i(0.72) : R.STEEL.i(0.26));
        s.rect(x, 5, 4, 2, R.BLACK.i(0.16));
        s.rect(x + 1, 5, 2, 1, R.STEEL.i(0.95));
      }
      s.rect(17, 22, 26, 4, R.STEEL.i(0.62));           /* trunnion     */
      s.rect(16, 26, 26, 12, R.TECH.i(0.36));           /* body         */
      s.rect(16, 26, 26, 2, R.TECH.i(0.66));
      s.rect(19, 30, 6, 4, R.BLACK.i(0.2));
      s.rect(20, 31, 2, 2, B.AMBER);                    /* charge lamp  */
      s.rect(28, 30, 10, 4, R.STEEL.i(0.3));
      for (var b = 0; b < 6; b++) {                      /* ammo belt    */
        s.rect(42 + b * 2, 34 + b * 3, 5, 4, R.DEMON2.i(0.7));
        s.rect(42 + b * 2, 34 + b * 3, 5, 1, R.STEEL.i(0.7));
      }
      arm(s, 24, 42, 0, -1);
      arm(s, 46, 46, 0, 1);
      o.chaingun = s.outline(R.BLACK.i(0.06)).frame32();
      o.muzzle.chaingun = [28, 5];
    })();

    /* muzzle flash (3 frames) */
    o.flash = [];
    for (var f = 0; f < 3; f++) {
      var s = new SC(36, 36), r = 8 + f * 3;
      s.ellipse(18, 18, r, r, B.ORANGE);
      s.ellipse(18, 18, (r * 0.72) | 0, (r * 0.72) | 0, B.YELLOW);
      s.ellipse(18, 18, (r * 0.45) | 0, (r * 0.45) | 0, B.WHITE);
      for (var k = 0; k < 8; k++) {
        var a = k * Math.PI / 4 + f * 0.3;
        s.line(18, 18, 18 + Math.cos(a) * r * 1.3, 18 + Math.sin(a) * r * 1.3, 2, B.YELLOW);
      }
      o.flash.push(s.frame32());
    }
    return o;
  }

  var ART = {
    enemies: buildEnemyFrames(),
    props: buildProps(),
    hands: buildHands()
  };

  /* ------------------------------------------------ billboard renderer */
  /*
   *  view = {x,y,dirX,dirY,planeX,planeY,horizon}
   *  sp   = {x,y,frame,scale,vOff,shade,alpha}
   *  scale = sprite height in wall-height units
   *  vOff  = feet height above the floor, in wall-height units
   */
  function drawSprite(fb, view, sp, zbuf) {
    var fr = sp.frame;
    if (!fr) return;
    var spx = sp.x - view.x, spy = sp.y - view.y;

    var det = view.planeX * view.dirY - view.dirX * view.planeY;
    if (Math.abs(det) < 1e-9) return;
    var invDet = 1.0 / det;
    var tX = invDet * (view.dirY * spx - view.dirX * spy);
    var tY = invDet * (-view.planeY * spx + view.planeX * spy);
    if (tY <= 0.12) return;

    var w = fb.w, h = fb.h, buf = fb.data32;
    var screenX = (w >> 1) * (1 + tX / tY);
    var spriteH = Math.abs(h / tY) * sp.scale;
    if (spriteH < 1 || spriteH > h * 24) return;
    var spriteW = spriteH * (fr.w / fr.h);
    if (spriteW < 1) return;

    var floorY = view.horizon + (h * 0.5) / tY;
    var cy = floorY - spriteH - (h * sp.vOff) / tY;
    var y0 = Math.floor(cy), y1 = Math.ceil(cy + spriteH);
    var x0 = Math.floor(screenX - spriteW * 0.5), x1 = Math.ceil(screenX + spriteW * 0.5);

    var shade = sp.shade | 0;
    var row = (sp.pain ? P.SHADE_PAIN : shade) * 256;
    var aw = fr.w, ah = fr.h, ad = fr.d;
    var BB = P.BRIGHT_BASE, pal = P.PALETTE, SH = P.SHADE;
    var texStepX = (aw * 65536) / spriteW;
    var texStepY = (ah * 65536) / spriteH;

    var xs = x0 < 0 ? 0 : x0, xe = x1 > w ? w : x1;
    var ys = y0 < 0 ? 0 : y0, ye = y1 > h ? h : y1;

    for (var x = xs; x < xe; x++) {
      if (zbuf[x] <= tY) continue;                       /* wall occludes */
      var texX = ((x - x0) * texStepX) >> 16;
      if (texX >= aw) texX = aw - 1;
      var ty = (ys - y0) * texStepY;
      var idx = ys * w + x;
      for (var y = ys; y < ye; y++, idx += w) {
        var c = ad[(ty >> 16) * aw + texX];
        ty += texStepY;
        if (c === 0) continue;                           /* transparent */
        buf[idx] = c >= BB ? pal[c] : SH[row + c];       /* bright glows, else fogged */
      }
    }
  }

  /* simple square particle billboard (blood, sparks, smoke) */
  function drawParticle(fb, view, p, zbuf) {
    var spx = p.x - view.x, spy = p.y - view.y;
    var det = view.planeX * view.dirY - view.dirX * view.planeY;
    var invDet = 1.0 / det;
    var tX = invDet * (view.dirY * spx - view.dirX * spy);
    var tY = invDet * (-view.planeY * spx + view.planeX * spy);
    if (tY <= 0.15) return;
    var w = fb.w, h = fb.h, buf = fb.data32;
    var screenX = (w >> 1) * (1 + tX / tY);
    var size = Math.max(1, (h / tY) * p.size);
    var cy = view.horizon + (h * 0.5) / tY - (h * p.z) / tY;
    var x0 = Math.round(screenX - size * 0.5), x1 = Math.round(screenX + size * 0.5);
    var y0 = Math.round(cy - size * 0.5), y1 = Math.round(cy + size * 0.5);
    var row = (P.shadeForDist(tY) + p.dim) * 256;
    if (row > (P.SHADES - 1) * 256) row = (P.SHADES - 1) * 256;
    var col = p.color >= P.BRIGHT_BASE ? P.PALETTE[p.color] : P.SHADE[row + p.color];
    var xs = Math.max(0, x0), xe = Math.min(w, x1), ys = Math.max(0, y0), ye = Math.min(h, y1);
    for (var x = xs; x < xe; x++) {
      if (zbuf[x] <= tY) continue;
      var idx = ys * w + x;
      for (var y = ys; y < ye; y++, idx += w) buf[idx] = col;
    }
  }

  /* rasterise a palette-index frame into a canvas (for HUD weapons) */
  function frameToCanvas(fr) {
    var c = document.createElement('canvas');
    c.width = fr.w; c.height = fr.h;
    var ctx = c.getContext('2d');
    var img = ctx.createImageData(fr.w, fr.h);
    var d32 = new Uint32Array(img.data.buffer);
    for (var i = 0; i < fr.d.length; i++) {
      var c2 = fr.d[i];
      d32[i] = c2 === 0 ? 0 : P.PALETTE[c2];
    }
    ctx.putImageData(img, 0, 0);
    return c;
  }

  var canvasCache = {};
  function frameCanvas(which, key, idx) {
    var id = which + '|' + key + '|' + idx;
    if (!canvasCache[id]) {
      var set = which === 'hands' ? ART.hands[key] : ART.props[key];
      var fr = (set && set.d) ? set : set[idx];   /* one frame, or a list   */
      canvasCache[id] = frameToCanvas(fr);
    }
    return canvasCache[id];
  }

  F.art = ART;
  F.sprites = {
    SC: SC, draw: drawSprite, drawParticle: drawParticle,
    frameToCanvas: frameToCanvas, frameCanvas: frameCanvas
  };
})(window.FPS = window.FPS || {});
