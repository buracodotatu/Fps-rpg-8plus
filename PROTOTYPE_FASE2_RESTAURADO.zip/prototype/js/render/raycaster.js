/* ============================================================
 * raycaster.js - the engine.
 *
 *  per frame:
 *    1. floor + ceiling cast (horizontal scan rows, per-pixel
 *       texture lookup, "open sky" tiles sample the sky instead
 *       of the ceiling texture)
 *    2. wall cast: classic DDA, textured columns, door tiles can
 *       be drawn partially risen, perp distance saved to z-buffer
 *    3. billboarded sprites + particles, far-to-near, per-column
 *       z-buffer test so walls correctly clip them
 *
 *  Everything writes into fb.data32 (a Uint32Array view over the
 *  ImageData) with palette-indexed textures + a shading LUT.
 * ============================================================ */
(function (F) {
  'use strict';

  var P = F.palette;
  var TEX = F.textures.SIZE;
  var TEXMASK = TEX - 1;

  var ray = {};

  /* level tile codes used by the renderer */
  var T = { FLOOR: 0, DOOR: 12, DOOR_LOCK: 13 };

  /* ---------------------------------------------------------- setup */
  ray.prepare = function (fb) {
    ray.w = fb.w; ray.h = fb.h; ray.buf = fb.data32; ray.z = fb.z;
  };

  /* ---------------------------------------------------------- sky */
  /* Precomputed per frame: skyU[x] is the texture column for that screen
     column, skyV[y] the texture row.  Keeps the sky to one array read
     per pixel instead of an atan2 per pixel. */
  function buildSkyLUT(view) {
    var w = ray.w, h = ray.h;
    if (!ray.skyU || ray.skyU.length !== w) { ray.skyU = new Int32Array(w); }
    if (!ray.skyV || ray.skyV.length !== h) { ray.skyV = new Int32Array(h); }
    for (var x = 0; x < w; x++) {
      var cx = 2 * x / w - 1;
      var ang = Math.atan2(view.dirY + view.planeY * cx, view.dirX + view.planeX * cx);
      var u = (ang / 6.2831853 + 0.5) * TEX * 2;
      var i = u | 0;
      ray.skyU[x] = i % TEX;
    }
    for (var y = 0; y < h; y++) {
      var sy = ((view.horizon - y) * TEX) / (h * 0.62);
      ray.skyV[y] = sy < 0 ? 0 : (sy > TEX - 1 ? TEX - 1 : sy | 0);
    }
  }
  var skyTex = F.textures.get(F.textures.id.SKY).data;

  /* ---------------------------------------------------------- floor/ceiling */
  function castPlanes(view) {
    var w = ray.w, h = ray.h, buf = ray.buf;
    var half = h * 0.5;
    var horizon = view.horizon;
    var lvl = ray.level;
    var LW = lvl.w, tiles = lvl.tiles, sky = lvl.sky, ftex = lvl.floorTex;
    var FLOOR_T = F.textures.get(F.textures.id.ASPHALT).data;
    var GRASS_T = F.textures.get(F.textures.id.GRASS).data;
    var GRATE_T = F.textures.get(F.textures.id.GRATE).data;
    var CEIL_T = F.textures.get(F.textures.id.CEILING).data;
    var GROUND = [FLOOR_T, FLOOR_T, GRASS_T, GRATE_T];
    var SHA = P.SHADE, pal = P.PALETTE, BB = P.BRIGHT_BASE;
    var FOGCOL = P.SHADE[(P.SHADES - 1) * 256 + 1];

    var rdx0 = view.dirX - view.planeX, rdy0 = view.dirY - view.planeY;
    var rdx1 = view.dirX + view.planeX, rdy1 = view.dirY + view.planeY;

    for (var y = 0; y < h; y++) {
      var isFloor = y > horizon;
      var p = isFloor ? (y - horizon) : (horizon - y);
      if (p < 1) p = 1;
      var rowDist = half / p;
      var shade = P.shadeForDist(rowDist);
      var row = shade * 256;
      var ofs = y * w;

      /* beyond the fog there is nothing to see: flat fill, big win */
      if (shade >= P.SHADES - 1 && (isFloor || !view.skyCount)) {
        for (var x = 0; x < w; x++) buf[ofs + x] = FOGCOL;
        continue;
      }

      var stepX = rowDist * (rdx1 - rdx0) / w;
      var stepY = rowDist * (rdy1 - rdy0) / w;
      var fx = view.x + rowDist * rdx0;
      var fy = view.y + rowDist * rdy0;

      if (!isFloor && view.skyCount) {
        /* ceiling row: sky where the map is open, ceiling texture inside */
        var skyRow = ray.skyV[y] * TEX;
        for (x = 0; x < w; x++) {
          var mx = fx | 0, my = fy | 0;
          var inside = !(mx >= 0 && my >= 0 && mx < LW && my < lvl.h && sky[my * LW + mx]);
          if (inside) {
            var tx = ((fx - mx) * TEX) & TEXMASK, ty = ((fy - my) * TEX) & TEXMASK;
            buf[ofs + x] = SHA[row + CEIL_T[ty * TEX + tx]];
          } else {
            var sc = skyTex[skyRow + ray.skyU[x]];
            buf[ofs + x] = sc >= BB ? pal[sc] : SHA[row + sc];
          }
          fx += stepX; fy += stepY;
        }
      } else {
        for (x = 0; x < w; x++) {
          var mx2 = fx | 0, my2 = fy | 0;
          var tex;
          if (isFloor) {
            var k = (mx2 >= 0 && my2 >= 0 && mx2 < LW && my2 < lvl.h) ? ftex[my2 * LW + mx2] : 0;
            tex = GROUND[k] || FLOOR_T;
          } else {
            tex = CEIL_T;
          }
          var tx2 = ((fx - mx2) * TEX) & TEXMASK, ty2 = ((fy - my2) * TEX) & TEXMASK;
          var c = tex[ty2 * TEX + tx2];
          buf[ofs + x] = c >= BB ? pal[c] : SHA[row + c];
          fx += stepX; fy += stepY;
        }
      }
    }
  }

  /* ---------------------------------------------------------- walls */
  function castWalls(view) {
    var w = ray.w, h = ray.h, buf = ray.buf, zb = ray.z;
    var lvl = ray.level;
    var LW = lvl.w, LH = lvl.h, tiles = lvl.tiles;
    var texOf = lvl.texOf, doorOpen = lvl.doorOpen;
    var texList = F.textures.list;
    var half = h * 0.5;
    var horizon = view.horizon;
    var posX = view.x, posY = view.y;
    var dirX = view.dirX, dirY = view.dirY, planeX = view.planeX, planeY = view.planeY;
    var SHA = P.SHADE;
    var SIDE_DARK = 3;                    /* extra fog on N/S faces */

    for (var x = 0; x < w; x++) {
      var cameraX = 2 * x / w - 1;
      var rayDirX = dirX + planeX * cameraX;
      var rayDirY = dirY + planeY * cameraX;

      var mapX = posX | 0, mapY = posY | 0;
      if (mapX < 0) mapX = 0; if (mapY < 0) mapY = 0;

      var ddx = rayDirX === 0 ? 1e30 : Math.abs(1 / rayDirX);
      var ddy = rayDirY === 0 ? 1e30 : Math.abs(1 / rayDirY);
      var stepX, stepY, sdx, sdy;
      if (rayDirX < 0) { stepX = -1; sdx = (posX - mapX) * ddx; }
      else { stepX = 1; sdx = (mapX + 1 - posX) * ddx; }
      if (rayDirY < 0) { stepY = -1; sdy = (posY - mapY) * ddy; }
      else { stepY = 1; sdy = (mapY + 1 - posY) * ddy; }

      var side = 0, tile = 0, hit = 0, guard = 0;
      while (guard++ < 512) {
        if (sdx < sdy) { sdx += ddx; mapX += stepX; side = 0; }
        else { sdy += ddy; mapY += stepY; side = 1; }
        if (mapX < 0 || mapY < 0 || mapX >= LW || mapY >= LH) break;
        var t = tiles[mapY * LW + mapX];
        if (t === T.FLOOR) continue;
        if (t === T.DOOR || t === T.DOOR_LOCK) {
          if (doorOpen[mapY * LW + mapX] > 0.985) continue;   /* fully open */
        }
        tile = t; hit = 1; break;
      }

      if (!hit) { zb[x] = 1e30; continue; }

      var perp = side === 0 ? (sdx - ddx) : (sdy - ddy);
      if (perp < 0.02) perp = 0.02;
      zb[x] = perp;

      var lineH = h / perp;
      var dStart = horizon - lineH * 0.5;
      var dEnd = horizon + lineH * 0.5;

      /* doors rise: paint only the still-closed top part */
      var open = 0;
      if (tile === T.DOOR || tile === T.DOOR_LOCK) open = doorOpen[mapY * LW + mapX];
      if (open > 0) dEnd = dStart + lineH * (1 - open);

      var y0 = dStart < 0 ? 0 : dStart | 0;
      var y1 = dEnd > h ? h : dEnd | 0;
      if (y1 <= y0) continue;

      var wallX = side === 0 ? (posY + perp * rayDirY) : (posX + perp * rayDirX);
      wallX -= Math.floor(wallX);
      var tex = texList[texOf[tile]].data;
      var texX = (wallX * TEX) | 0;
      if ((side === 0 && rayDirX > 0) || (side === 1 && rayDirY < 0)) texX = TEX - texX - 1;

      var shade = P.shadeForDist(perp) + (side === 1 ? SIDE_DARK : 0);
      if (shade > P.SHADES - 1) shade = P.SHADES - 1;
      var row = shade * 256;

      var visible = dEnd - dStart;
      var step = TEX / visible;
      var texPos = (y0 - dStart) * step;

      var idx = y0 * w + x;
      for (var y = y0; y < y1; y++, idx += w) {
        var ty = texPos & TEXMASK;
        texPos += step;
        buf[idx] = SHA[row + tex[(ty << 6) + texX]];
      }
    }
  }

  /* ---------------------------------------------------------- sprites */
  function drawSprites(view, list, n) {
    /* far -> near so overdraw is cheap and blending looks sane */
    for (var i = 0; i < n; i++) {
      var s = list[i];
      var dx = s.x - view.x, dy = s.y - view.y;
      s._d = dx * dx + dy * dy;
    }
    order.length = n;
    for (i = 0; i < n; i++) order[i] = i;
    order.sort(function (a, b) { return list[b]._d - list[a]._d; });

    for (i = 0; i < n; i++) {
      var sp = list[order[i]];
      if (sp.kind === 'particle') F.sprites.drawParticle(F.fb, view, sp, ray.z);
      else F.sprites.draw(F.fb, view, sp, ray.z);
    }
  }
  var order = [];

  /* ---------------------------------------------------------- full frame */
  ray.render = function (fb, level, view, sprites, nSprites) {
    ray.prepare(fb);
    ray.level = level;
    if (view.skyCount) buildSkyLUT(view);
    castPlanes(view);
    castWalls(view);
    if (nSprites) drawSprites(view, sprites, nSprites);
  };

  /* ---------------------------------------------------------- helpers */
  /* DDA used for hitscan / line-of-sight.  Returns distance to the first
     blocking surface (open doors are transparent), or maxD. */
  ray.castRay = function (level, posX, posY, dirX, dirY, maxD) {
    var mapX = posX | 0, mapY = posY | 0;
    var ddx = dirX === 0 ? 1e30 : Math.abs(1 / dirX);
    var ddy = dirY === 0 ? 1e30 : Math.abs(1 / dirY);
    var stepX, stepY, sdx, sdy;
    if (dirX < 0) { stepX = -1; sdx = (posX - mapX) * ddx; }
    else { stepX = 1; sdx = (mapX + 1 - posX) * ddx; }
    if (dirY < 0) { stepY = -1; sdy = (posY - mapY) * ddy; }
    else { stepY = 1; sdy = (mapY + 1 - posY) * ddy; }
    var side = 0, guard = 0, hit = 0, dist = maxD;
    while (guard++ < 512) {
      if (sdx < sdy) { sdx += ddx; mapX += stepX; side = 0; }
      else { sdy += ddy; mapY += stepY; side = 1; }
      var d = side === 0 ? (sdx - ddx) : (sdy - ddy);
      if (d > maxD) { dist = maxD; break; }
      if (mapX < 0 || mapY < 0 || mapX >= level.w || mapY >= level.h) { dist = maxD; break; }
      var t = level.tiles[mapY * level.w + mapX];
      if (t === T.FLOOR) continue;
      if (t === T.DOOR || t === T.DOOR_LOCK) {
        if (level.doorOpen[mapY * level.w + mapX] > 0.985) continue;
      }
      dist = d; hit = 1; break;
    }
    ray.hitDist = dist; ray.hitSide = side; ray.hitSolid = hit === 1;
    ray.hitMapX = mapX; ray.hitMapY = mapY; ray.hitTile = level.tiles[mapY * level.w + mapX] | 0;
    ray.hitX = posX + dirX * dist; ray.hitY = posY + dirY * dist;
    return dist;
  };

  ray.lineOfSight = function (level, x0, y0, x1, y1) {
    var dx = x1 - x0, dy = y1 - y0;
    var d = Math.sqrt(dx * dx + dy * dy);
    if (d < 1e-6) return true;
    ray.castRay(level, x0, y0, dx / d, dy / d, d);
    return !ray.hitSolid;
  };

  F.raycaster = ray;
})(window.FPS = window.FPS || {});
