/* ============================================================
 * framebuffer.js - the software framebuffer.
 *
 * One ImageData whose .data we view as a Uint32Array, so a pixel
 * write is a single 32-bit store.  The canvas element stays at the
 * low internal resolution and CSS stretches it (image-rendering:
 * pixelated), which is far cheaper than a JS-side upscale.
 * ============================================================ */
(function (F) {
  'use strict';

  var fb = {
    canvas: null, ctx: null,
    image: null, data32: null, data8: null,
    z: null,            /* per-column perpendicular wall distance */
    w: 0, h: 0, half: 0,
    clearCount: 0
  };

  fb.create = function (canvas, w, h) {
    fb.canvas = canvas;
    fb.w = w | 0; fb.h = h | 0; fb.half = fb.h >> 1;
    canvas.width = fb.w; canvas.height = fb.h;
    fb.ctx = canvas.getContext('2d', { alpha: false });
    fb.ctx.imageSmoothingEnabled = false;
    fb.realloc();
    return fb;
  };

  fb.realloc = function () {
    fb.image = fb.ctx.createImageData(fb.w, fb.h);
    fb.data8 = fb.image.data;
    fb.data32 = new Uint32Array(fb.data8.buffer);
    fb.z = new Float32Array(fb.w);
    fb.data32.fill(0xFF000000);
  };

  fb.resize = function (w, h) {
    w = Math.max(160, w | 0); h = Math.max(100, h | 0);
    if (w === fb.w && h === fb.h) return false;
    fb.w = w; fb.h = h; fb.half = h >> 1;
    fb.canvas.width = w; fb.canvas.height = h;
    fb.realloc();
    return true;
  };

  fb.clear = function (argb) { fb.data32.fill(argb >>> 0); fb.clearCount++; };

  /* decode a framebuffer pixel back to [r,g,b] using the same byte
     order the palette was packed with */
  fb.pixelAt = function (x, y) {
    var v = fb.data32[y * fb.w + x] >>> 0;
    return F.palette.littleEndian
      ? [v & 255, (v >> 8) & 255, (v >> 16) & 255]
      : [(v >> 24) & 255, (v >> 16) & 255, (v >> 8) & 255];
  };

  /* push the software buffer to the canvas (CSS stretches it up) */
  fb.present = function () { fb.ctx.putImageData(fb.image, 0, 0); };

  /* read back what the canvas actually shows - catches "wrote the buffer
     but never presented it" bugs that stats() alone cannot see */
  fb.canvasStats = function () {
    var d = fb.ctx.getImageData(0, 0, fb.w, fb.h).data;
    var n = 0, nonBlack = 0, sum = 0, hist = Object.create(null), distinct = 0;
    for (var i = 0; i < d.length; i += 4 * 7) {
      var r = d[i], g = d[i + 1], b = d[i + 2];
      n++;
      if (r + g + b > 24) nonBlack++;
      sum += r * 0.299 + g * 0.587 + b * 0.114;
      var key = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
      if (!hist[key]) { hist[key] = 1; distinct++; }
    }
    return {
      nonBlackPct: +(nonBlack / n * 100).toFixed(1),
      meanLuma: +(sum / n).toFixed(1),
      distinctColors: distinct
    };
  };

  /* fill helpers used by the sky / debug paths */
  fb.fillRect = function (x0, y0, x1, y1, argb) {
    var d = fb.data32, w = fb.w, h = fb.h;
    x0 = Math.max(0, x0 | 0); x1 = Math.min(w, x1 | 0);
    y0 = Math.max(0, y0 | 0); y1 = Math.min(h, y1 | 0);
    for (var y = y0; y < y1; y++) {
      var o = y * w;
      for (var x = x0; x < x1; x++) d[o + x] = argb >>> 0;
    }
  };

  /* ---- verification helper: is anything actually on screen? ---- */
  fb.stats = function () {
    var d = fb.data32, n = d.length;
    var hist = Object.create(null), distinct = 0, sum = 0, nonBlack = 0;
    var top = 0, bottom = 0, topN = 0, bottomN = 0, w = fb.w, h = fb.h;
    for (var i = 0; i < n; i += 7) {                 /* stride sample */
      var rgb = fb.pixelAt(i % w, (i / w) | 0);
      var r = rgb[0], g = rgb[1], b = rgb[2];
      var lum = r * 0.299 + g * 0.587 + b * 0.114;
      if (r + g + b > 24) nonBlack++;
      sum += lum;
      var px = i % w, py = (i / w) | 0;
      if (py < h * 0.25) { top += lum; topN++; }
      else if (py > h * 0.75) { bottom += lum; bottomN++; }
      var key = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
      if (!hist[key]) { hist[key] = 1; distinct++; }
    }
    var samples = Math.ceil(n / 7);
    return {
      pixels: fb.w * fb.h,
      sampled: samples,
      distinctColors: distinct,
      nonBlackPct: +(nonBlack / samples * 100).toFixed(1),
      meanLuma: +(sum / samples).toFixed(1),
      skyLuma: +(top / Math.max(1, topN)).toFixed(1),
      floorLuma: +(bottom / Math.max(1, bottomN)).toFixed(1)
    };
  };

  /* dump the buffer into a PNG-friendly dataURL (debug / tests) */
  fb.toDataURL = function (scale) {
    scale = scale || 1;
    var c = document.createElement('canvas');
    c.width = fb.w * scale; c.height = fb.h * scale;
    var x = c.getContext('2d');
    x.imageSmoothingEnabled = false;
    x.putImageData(fb.image, 0, 0);
    if (scale > 1) {
      var c2 = document.createElement('canvas');
      c2.width = c.width; c2.height = c.height;
      var x2 = c2.getContext('2d'); x2.imageSmoothingEnabled = false;
      x2.drawImage(c, 0, 0, c2.width, c2.height);
      return c2.toDataURL('image/png');
    }
    return c.toDataURL('image/png');
  };

  F.fb = fb;
})(window.FPS = window.FPS || {});
