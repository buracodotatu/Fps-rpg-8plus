/* ============================================================
 * player.js - player state and movement for the prototype.
 * Interface compatível com o raycaster do DOOMED:
 *   view = { x, y, dirX, dirY, planeX, planeY, horizon, skyCount }
 *
 * CORREÇÃO v0.2:
 *   - horizon usa altura do framebuffer (F.fb.h), não level.h
 *   - horizon sempre recalculado em update(), mesmo parado
 *   - horizon inicializado em reset()
 * ============================================================ */
(function (F) {
  'use strict';
  var IN = F.input;

  var player = {
    x: 1.5,
    y: 1.5,
    dirX: 1.0,
    dirY: 0.0,
    planeX: 0.0,
    planeY: 0.66,
    horizon: 90,   /* fallback; reset() e update() sobrescrevem */
    skyCount: 0,
    pitch: 0
  };

  var MOVE_SPEED = 3.0;
  var ROT_SPEED = 2.2;
  var MOUSE_SENS = 0.0022;
  var MAX_PITCH = 0.35;

  function fbHeight() {
    return (F.fb && F.fb.h) ? F.fb.h : 180;
  }

  function canStand(level, x, y) {
    var r = 0.22;
    if (level.tiles[(y-r|0)*level.w + (x-r|0)] !== 0) return false;
    if (level.tiles[(y-r|0)*level.w + (x+r|0)] !== 0) return false;
    if (level.tiles[(y+r|0)*level.w + (x-r|0)] !== 0) return false;
    if (level.tiles[(y+r|0)*level.w + (x+r|0)] !== 0) return false;
    return true;
  }

  function rotate(angle) {
    var c = Math.cos(angle), s = Math.sin(angle);
    var ndx = player.dirX*c - player.dirY*s;
    var ndy = player.dirX*s + player.dirY*c;
    player.dirX = ndx; player.dirY = ndy;
    var npx = player.planeX*c - player.planeY*s;
    var npy = player.planeX*s + player.planeY*c;
    player.planeX = npx; player.planeY = npy;
  }

  player.update = function (dt, level) {

    /* ---------- ROTAÇÃO (sempre) ---------- */
    var m = IN.consumeMouse();
    if (m[0]) rotate(m[0] * MOUSE_SENS);
    if (m[1]) {
      player.pitch -= m[1] * MOUSE_SENS;
      if (player.pitch > MAX_PITCH)  player.pitch = MAX_PITCH;
      if (player.pitch < -MAX_PITCH) player.pitch = -MAX_PITCH;
    }

    var turn = IN.axis('ArrowLeft', 'ArrowRight') + IN.axis('KeyQ', 'KeyE');
    if (turn) rotate(turn * ROT_SPEED * dt);

    /* ---------- MOVIMENTO (condicional, sem early return) ---------- */
    var fwd = IN.axisA('KeyS', 'KeyW', IN.stick.active ? IN.stick.y : 0);
    var str = IN.axisA('KeyA', 'KeyD', IN.stick.active ? IN.stick.x : 0);

    if (fwd !== 0 || str !== 0) {
      var len = Math.sqrt(fwd*fwd + str*str);
      if (len > 1) { fwd /= len; str /= len; }

      var speed = MOVE_SPEED * (IN.touchRun || IN.down('ShiftLeft') ? 1.6 : 1.0);
      var step = speed * dt;
      var dx = (player.dirX*fwd - player.dirY*str) * step;
      var dy = (player.dirY*fwd + player.dirX*str) * step;

      var nx = player.x + dx;
      if (canStand(level, nx, player.y)) player.x = nx;
      var ny = player.y + dy;
      if (canStand(level, player.x, ny)) player.y = ny;
    }

    /* ---------- HORIZONTE (sempre) ----------
       Referência: altura do FRAMEBUFFER, não do mapa.
       fb.h / 2 = centro da tela quando pitch = 0. */
    var h = fbHeight();
    player.horizon = h * 0.5 + player.pitch * h;
  };

  player.reset = function () {
    player.x = 1.5; player.y = 1.5;
    player.dirX = 1.0; player.dirY = 0.0;
    player.planeX = 0.0; player.planeY = 0.66;
    player.pitch = 0;
    player.horizon = fbHeight() * 0.5;
  };

  F.player = player;
})(window.FPS = window.FPS || {});