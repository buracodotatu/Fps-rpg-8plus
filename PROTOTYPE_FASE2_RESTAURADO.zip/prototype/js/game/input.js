/* ============================================================
 * input.js - keyboard + pointer lock mouse look + analog touch.
 * Accumulates mouse deltas / wheel / fire presses per frame.
 *
 * Touch devices (coarse pointers) never get Pointer Lock, so they
 * drive the same accumulators through synthetic deltas: `stick`
 * feeds movement, drags feed mx/my, buttons feed keys/fire.
 * ============================================================ */
(function (F) {
  'use strict';

  /* coarse pointer = phone/tablet.  A touchscreen laptop still reports a
     fine pointer, so it keeps the keyboard+mouse path untouched.        */
  var coarse = (function () {
    try {
      if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) return true;
      if (window.matchMedia && window.matchMedia('(pointer: fine)').matches) return false;
    } catch (e) {}
    return typeof window.ontouchstart !== 'undefined' || (navigator.maxTouchPoints || 0) > 0;
  })();

  var IN = {
    keys: Object.create(null),
    mx: 0, my: 0,            /* accumulated look delta this frame */
    wheel: 0,
    fireDown: false,         /* held */
    firePressed: false,      /* edge  */
    locked: false,
    enabled: true,
    sensitivity: 0.0022,
    touchSens: 1.75,         /* finger drags are scaled by this before mx/my */
    invertY: false,
    target: null,
    onLockChange: null,
    onBlock: null,           /* swallow keys the menus care about */
    coarse: coarse,          /* touch-first device */
    /* analog move stick, -1..1.  y is forward (+), x is strafe (+). */
    stick: { x: 0, y: 0, active: false },
    touchRun: false          /* stick pushed to the rim */
  };

  var BLOCKED = { Tab: 1, F1: 1, F5: 1, F12: 1 };

  function keyDown(e) {
    if (BLOCKED[e.code]) e.preventDefault();
    if (!IN.enabled && e.code !== 'Escape') return;
    if (!IN.keys[e.code]) IN.keys[e.code + '_edge'] = true;
    IN.keys[e.code] = true;
    if (IN.onBlock) IN.onBlock(e);
  }
  function keyUp(e) { IN.keys[e.code] = false; }

  function onMouseMove(e) {
    if (!IN.locked || !IN.enabled) return;
    var dx = e.movementX || 0, dy = e.movementY || 0;
    /* some engines deliver huge deltas on the first event */
    if (Math.abs(dx) > 200) dx = 0;
    if (Math.abs(dy) > 200) dy = 0;
    IN.mx += dx; IN.my += dy;
  }
  function onMouseDown(e) {
    if (e.button !== 0) return;
    if (!IN.locked) { if (IN.target) IN.requestLock(); return; }
    IN.fireDown = true; IN.firePressed = true;
  }
  function onMouseUp(e) { if (e.button === 0) IN.fireDown = false; }
  function onWheel(e) { IN.wheel += Math.sign(e.deltaY); e.preventDefault(); }

  function onLockChange() {
    IN.locked = document.pointerLockElement === IN.target;
    if (!IN.locked) { IN.fireDown = false; IN.mx = IN.my = 0; }
    if (IN.onLockChange) IN.onLockChange(IN.locked);
  }
  function onError(e) { if (IN.onLockChange) IN.onLockChange(false); }

  IN.attach = function (canvas) {
    IN.target = canvas;
    window.addEventListener('keydown', keyDown, false);
    window.addEventListener('keyup', keyUp, false);
    window.addEventListener('mousemove', onMouseMove, false);
    window.addEventListener('mousedown', onMouseDown, false);
    window.addEventListener('mouseup', onMouseUp, false);
    canvas.addEventListener('wheel', onWheel, { passive: false });
    document.addEventListener('pointerlockchange', onLockChange, false);
    document.addEventListener('pointerlockerror', onError, false);
    window.addEventListener('blur', function () { IN.keys = Object.create(null); IN.fireDown = false; });
  };

  IN.requestLock = function () {
    /* Pointer Lock simply does not exist on iOS Safari - on a coarse
       pointer we never ask for it, so nothing can block the start.    */
    if (!IN.target || IN.locked || IN.coarse) return;
    if (!IN.target.requestPointerLock && !IN.target.mozRequestPointerLock) return;
    var p = IN.target.requestPointerLock || IN.target.mozRequestPointerLock;
    /* Chrome returns a promise that rejects without a user gesture */
    if (p) { try { var r = p.call(IN.target); if (r && r.catch) r.catch(function () {}); } catch (e) {} }
  };
  IN.releaseLock = function () {
    if (document.exitPointerLock || document.mozExitPointerLock) {
      try { (document.exitPointerLock || document.mozExitPointerLock).call(document); } catch (e) {}
    }
    IN.locked = false;
  };

  IN.down = function (code) { return !!IN.keys[code]; };
  /* true exactly once, on the frame the key went down */
  IN.pressed = function (code) {
    if (IN.keys[code + '_edge']) { IN.keys[code + '_edge'] = false; return true; }
    return false;
  };
  IN.axis = function (neg, pos) { return (IN.down(pos) ? 1 : 0) - (IN.down(neg) ? 1 : 0); };
  /* Same as axis() but adds a continuous analog contribution, so a
     half-tilted thumb walks and a full tilt runs. Keyboard is unchanged. */
  IN.axisA = function (neg, pos, analog) {
    var v = (IN.down(pos) ? 1 : 0) - (IN.down(neg) ? 1 : 0);
    if (analog) v += analog;
    return v < -1 ? -1 : v > 1 ? 1 : v;
  };
  /* let a touch button drive anything that polls a key */
  IN.pressKey = function (code) {
    if (!IN.keys[code]) IN.keys[code + '_edge'] = true;
    IN.keys[code] = true;
  };
  IN.releaseKey = function (code) { IN.keys[code] = false; };
  IN.resetMove = function () {
    IN.stick.x = 0; IN.stick.y = 0; IN.stick.active = false; IN.touchRun = false;
    IN.fireDown = false;
  };
  IN.consumeMouse = function () { var m = [IN.mx, IN.my]; IN.mx = IN.my = 0; return m; };
  IN.consumeWheel = function () { var w = IN.wheel; IN.wheel = 0; return w; };
  IN.consumeFire = function () { var f = IN.firePressed; IN.firePressed = false; return f; };

  F.input = IN;
})(window.FPS = window.FPS || {});
