/* ============================================================
 * level.js - static level for the prototype.
 * Compatível com o raycaster do DOOMED.
 * ============================================================ */
(function (F) {
  'use strict';

  var W = 16, H = 16;

  /* 0 = chão, 1 = tijolo, 2 = pedra, 3 = tech */
  var grid = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,2,2,0,0,0,0,0,0,0,3,3,0,0,1],
    [1,0,2,0,0,0,0,0,0,0,0,0,3,0,0,1],
    [1,0,2,0,0,1,1,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,2,2,2,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,2,0,2,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,2,2,2,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,3,3,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,3,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,3,3,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
  ];

  function buildLevel() {
    var tiles = new Uint8Array(W*H);
    var sky = new Uint8Array(W*H);
    var floorTex = new Uint8Array(W*H);
    var doorOpen = new Float32Array(W*H);

    for (var y = 0; y < H; y++) {
      for (var x = 0; x < W; x++) {
        var i = y*W + x;
        tiles[i] = grid[y][x];
        sky[i] = 0;        /* sem céu aberto */
        floorTex[i] = 0;   /* asfalto */
        doorOpen[i] = 0;
      }
    }

    var TEX = F.textures.id;
    var texOf = [];
    texOf[0] = TEX.ASPHALT;
    texOf[1] = TEX.BRICK;
    texOf[2] = TEX.STONE;
    texOf[3] = TEX.TECH;

    return {
      w: W, h: H,
      tiles: tiles,
      sky: sky,
      floorTex: floorTex,
      texOf: texOf,
      doorOpen: doorOpen
    };
  }

  F.level = buildLevel();
})(window.FPS = window.FPS || {});