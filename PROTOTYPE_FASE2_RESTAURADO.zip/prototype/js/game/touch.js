/* ============================================================
 * touch.js - twin-stick touch controls for coarse-pointer devices.
 * Base: DOOMED (MIT, hyunhwan-bcm).
 *
 * CORREÇÃO v0.2:
 *   - isUI reconhece .res-btn e <button>
 *   - preventDefault só quando um toque é efetivamente consumido
 *   - flag T.active impede ativação antes do boot
 *   - multitouch preservado (moveId e lookId independentes)
 * ============================================================ */
(function (F) {
  'use strict';
  var IN = F.input;
  var RADIUS = 44;
  var DEAD = 7;
  var RUN_AT = 0.94;

  var T = {
    attached: false, moveId: -1, lookId: -1,
    ox: 0, oy: 0, lx: 0, ly: 0, zones: null,
    active: false
  };

  function isUI(t) {
    var el = t.target;
    if (!el || !el.closest) return false;
    if (el.closest('.res-btn')) return true;
    if (el.closest('.tb'))      return true;
    if (el.closest('button'))   return true;
    if (el.closest('#boot-overlay')) return true;
    return false;
  }

  function isPanel(t) {
    var el = t.target;
    return !!(el && el.closest && el.closest('#overlay.show'));
  }

  function setKnob(dx, dy) {
    if (!T.zones || !T.zones.knob) return;
    T.zones.knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
  }
  function showBase(x, y) {
    var b = T.zones && T.zones.base; if (!b) return;
    b.style.left = x + 'px'; b.style.top = y + 'px';
    b.classList.add('on');
  }
  function hideBase() {
    if (T.zones && T.zones.base) T.zones.base.classList.remove('on');
    setKnob(0, 0);
  }
  function resetStick() {
    IN.stick.x = 0; IN.stick.y = 0; IN.stick.active = false;
    IN.touchRun = false; hideBase();
  }
  function updateStick(x, y) {
    var dx = x - T.ox, dy = y - T.oy;
    var m = Math.hypot(dx, dy);
    if (m <= DEAD) {
      IN.stick.x = 0; IN.stick.y = 0; IN.touchRun = false;
      setKnob(0, 0); return;
    }
    var k = Math.min(1, (m-DEAD)/(RADIUS-DEAD))/m;
    IN.stick.x = dx*k; IN.stick.y = -dy*k;
    IN.stick.active = true;
    IN.touchRun = m >= RADIUS*RUN_AT;
    var vis = Math.min(m, RADIUS);
    setKnob((dx/m)*vis, (dy/m)*vis);
  }

  function onStart(e) {
    if (!T.active) return;

    var w = window.innerWidth;
    var handled = false;

    for (var i = 0; i < e.changedTouches.length; i++) {
      var t = e.changedTouches[i];
      if (isUI(t) || isPanel(t)) continue;

      if (T.moveId < 0 && t.clientX < w * 0.5) {
        T.moveId = t.identifier;
        T.ox = t.clientX; T.oy = t.clientY;
        showBase(t.clientX, t.clientY);
        handled = true;
      } else if (T.lookId < 0) {
        T.lookId = t.identifier;
        T.lx = t.clientX; T.ly = t.clientY;
        handled = true;
      }
    }
    if (handled) e.preventDefault();
  }

  function onMove(e) {
    if (!T.active) return;
    var handled = false;
    for (var i = 0; i < e.changedTouches.length; i++) {
      var t = e.changedTouches[i];
      if (t.identifier === T.moveId) {
        updateStick(t.clientX, t.clientY);
        handled = true;
      } else if (t.identifier === T.lookId) {
        IN.mx += (t.clientX - T.lx) * IN.touchSens;
        IN.my += (t.clientY - T.ly) * IN.touchSens;
        T.lx = t.clientX; T.ly = t.clientY;
        handled = true;
      }
    }
    if (handled) e.preventDefault();
  }

  function onEnd(e) {
    for (var i = 0; i < e.changedTouches.length; i++) {
      var id = e.changedTouches[i].identifier;
      if (id === T.moveId) { T.moveId = -1; resetStick(); }
      if (id === T.lookId) T.lookId = -1;
    }
  }

  T.attach = function (stage) {
    if (T.attached) return T;
    T.attached = true;
    T.zones = {
      base: document.getElementById('tstick'),
      knob: document.getElementById('tstick-knob')
    };
    stage.addEventListener('touchstart', onStart, { passive: false });
    stage.addEventListener('touchmove',  onMove,  { passive: false });
    stage.addEventListener('touchend',   onEnd,   { passive: false });
    stage.addEventListener('touchcancel', onEnd,  { passive: false });
    window.addEventListener('blur', function () {
      T.moveId = -1; T.lookId = -1; resetStick(); IN.fireDown = false;
    });
    document.body.classList.add('touch');
    return T;
  };

  T.setActive = function (v) { T.active = !!v; };
  T.enabled = function () { return T.attached; };
  F.touch = T;
})(window.FPS = window.FPS || {});