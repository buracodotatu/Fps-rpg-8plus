/* ============================================================
 * diagnostics.js - registro de erros, avisos, contadores e
 * métricas em memória.
 *
 * Fase 2 (serviços fundamentais). Sem DOM. Sem dependências
 * circulares. Sem logs por quadro. Tudo em memória, com limites
 * defensivos. Pode ser desativado sem afetar o jogo.
 *
 * CORREÇÃO (auditoria Fase 2):
 *   - counters e measures usam Object.create(null); chaves
 *     como '__proto__' não atingem mais Object.prototype.
 *   - caps: MAX_COUNTER_KEYS (128) e MAX_MEASURE_KEYS (64).
 *   - comportamento no cap: chaves NOVAS são descartadas;
 *     chaves já registradas continuam atualizando.
 *   - descartes são contados em droppedCounterKeys /
 *     droppedMeasureKeys e expostos em getState().meta.
 *   - getState() devolve counters/measures como null-proto.
 * ============================================================ */
(function (F) {
  'use strict';

  var enabled = true;

  var MAX_ERRORS        = 64;
  var MAX_WARNINGS      = 64;
  var MAX_COUNTER_KEYS  = 128;
  var MAX_MEASURE_KEYS  = 64;

  var errors = [];      /* { t, msg, meta } */
  var warnings = [];    /* { t, msg, meta } */
  var counters = Object.create(null);   /* chave -> número */
  var measures = Object.create(null);   /* chave -> { n, sum, min, max, last } */
  var counterKeys = 0;
  var measureKeys = 0;
  var droppedCounterKeys = 0;
  var droppedMeasureKeys = 0;

  function nowWall() {
    return (typeof performance !== 'undefined' && performance.now)
      ? performance.now()
      : Date.now();
  }

  function pushCapped(arr, cap, item) {
    arr.push(item);
    if (arr.length > cap) arr.splice(0, arr.length - cap);
  }

  function isEnabled() { return enabled; }
  function enable()    { enabled = true; }
  function disable()   { enabled = false; }

  function record(message, meta) {
    if (!enabled) return;
    pushCapped(errors, MAX_ERRORS, {
      t: nowWall(),
      msg: String(message),
      meta: meta === undefined ? null : meta
    });
  }

  function warn(message, meta) {
    if (!enabled) return;
    pushCapped(warnings, MAX_WARNINGS, {
      t: nowWall(),
      msg: String(message),
      meta: meta === undefined ? null : meta
    });
  }

  function count(key, n) {
    if (!enabled) return;
    var k = String(key);
    var add = (typeof n === 'number' && isFinite(n)) ? n : 1;
    if (!Object.prototype.hasOwnProperty.call(counters, k)) {
      if (counterKeys >= MAX_COUNTER_KEYS) {
        droppedCounterKeys++;
        return;
      }
      counterKeys++;
    }
    counters[k] = (counters[k] || 0) + add;
  }

  function measure(key, value) {
    if (!enabled) return;
    if (typeof value !== 'number' || !isFinite(value)) return;
    var k = String(key);
    var m;
    if (Object.prototype.hasOwnProperty.call(measures, k)) {
      m = measures[k];
    } else {
      if (measureKeys >= MAX_MEASURE_KEYS) {
        droppedMeasureKeys++;
        return;
      }
      measureKeys++;
      m = measures[k] = { n: 0, sum: 0, min: Infinity, max: -Infinity, last: 0 };
    }
    m.n++;
    m.sum += value;
    if (value < m.min) m.min = value;
    if (value > m.max) m.max = value;
    m.last = value;
  }

  function snapshot() {
    var c = Object.create(null);
    var m = Object.create(null);
    for (var k in counters) {
      if (Object.prototype.hasOwnProperty.call(counters, k)) c[k] = counters[k];
    }
    for (var j in measures) {
      if (Object.prototype.hasOwnProperty.call(measures, j)) {
        var src = measures[j];
        m[j] = {
          n: src.n, sum: src.sum, min: src.min, max: src.max, last: src.last,
          avg: src.n > 0 ? src.sum / src.n : 0
        };
      }
    }
    return {
      enabled: enabled,
      errors: errors.slice(),
      warnings: warnings.slice(),
      counters: c,
      measures: m,
      meta: {
        counterKeys: counterKeys,
        measureKeys: measureKeys,
        droppedCounterKeys: droppedCounterKeys,
        droppedMeasureKeys: droppedMeasureKeys,
        maxCounterKeys: MAX_COUNTER_KEYS,
        maxMeasureKeys: MAX_MEASURE_KEYS,
        maxErrors: MAX_ERRORS,
        maxWarnings: MAX_WARNINGS
      }
    };
  }

  function clear() {
    errors = [];
    warnings = [];
    counters = Object.create(null);
    measures = Object.create(null);
    counterKeys = 0;
    measureKeys = 0;
    droppedCounterKeys = 0;
    droppedMeasureKeys = 0;
  }

  F.diagnostics = {
    isEnabled: isEnabled,
    enable: enable,
    disable: disable,
    record: record,
    warn: warn,
    count: count,
    measure: measure,
    getState: snapshot,
    clear: clear
  };
})(window.FPS = window.FPS || {});
