/* ============================================================
 * timers.js - serviço de temporizadores lógicos.
 *
 * Fase 2 (serviços fundamentais). Independente do loop de render.
 * O jogo deverá chamar FPS.timers.update(dtMs) a partir do seu
 * loop existente (main.js) numa fase futura. Esta missão NÃO
 * altera main.js.
 *
 * CORREÇÃO (auditoria Fase 2):
 *   - ao atingir MAX_TIMERS, emite UM aviso via FPS.diagnostics
 *     (não silencia mais); aviso repetido é suprimido até o
 *     número de temporizadores cair abaixo do limite.
 *
 * Regras:
 *  - relógio lógico próprio; nunca usa Date.now() para lógica
 *  - no máximo 1 disparo por repetido por chamada de update
 *    (evita rajadas depois de queda de FPS / travamento)
 *  - erros de callback isolados
 *  - limites defensivos: MAX_TIMERS, MAX_DELAY, MIN_INTERVAL
 * ============================================================ */
(function (F) {
  'use strict';

  var logicalTime = 0;        /* ms */
  var timers = Object.create(null);   /* id -> { fireAt, interval, cb, options } */
  var timerCount = 0;
  var nextId = 1;
  var limitWarned = false;    /* evita inundar diagnostics */

  var MAX_TIMERS   = 512;
  var MAX_DELAY    = 24 * 60 * 60 * 1000; /* 24h */
  var MIN_INTERVAL = 1;                    /* 1 ms */

  function isFn(x) { return typeof x === 'function'; }

  function clampDelay(d) {
    if (typeof d !== 'number' || !isFinite(d) || d < 0) return 0;
    return d > MAX_DELAY ? MAX_DELAY : d;
  }

  function reportError(e) {
    if (F.diagnostics && F.diagnostics.record) {
      F.diagnostics.record('timers:callback', e);
    }
  }

  function warnLimitOnce() {
    if (limitWarned) return;
    limitWarned = true;
    if (F.diagnostics && F.diagnostics.warn) {
      F.diagnostics.warn('timers:max-reached', { max: MAX_TIMERS });
    }
  }

  function schedule(delayMs, cb, options) {
    if (!isFn(cb)) return null;
    if (timerCount >= MAX_TIMERS) { warnLimitOnce(); return null; }
    var id = nextId++;
    timers[id] = {
      fireAt: logicalTime + clampDelay(delayMs),
      interval: 0,
      cb: cb,
      options: options || null
    };
    timerCount++;
    return id;
  }

  function scheduleEvery(intervalMs, cb, options) {
    if (!isFn(cb)) return null;
    if (timerCount >= MAX_TIMERS) { warnLimitOnce(); return null; }
    var iv = clampDelay(intervalMs);
    if (iv < MIN_INTERVAL) iv = MIN_INTERVAL;
    var opts = options || null;
    var immediate = !!(opts && opts.startImmediate);
    var id = nextId++;
    timers[id] = {
      fireAt: logicalTime + (immediate ? 0 : iv),
      interval: iv,
      cb: cb,
      options: opts
    };
    timerCount++;
    return id;
  }

  function cancel(id) {
    if (!timers[id]) return false;
    delete timers[id];
    timerCount--;
    if (timerCount < MAX_TIMERS) limitWarned = false;
    return true;
  }

  function update(deltaMs) {
    if (typeof deltaMs !== 'number' || !isFinite(deltaMs) || deltaMs <= 0) return;
    logicalTime += deltaMs;

    var ids = Object.keys(timers);
    for (var i = 0; i < ids.length; i++) {
      var id = ids[i];
      var t = timers[id];
      if (!t) continue;                 /* cancelado por callback anterior */
      if (logicalTime < t.fireAt) continue;

      if (t.interval > 0) {
        try { t.cb(); } catch (e) { reportError(e); }
        if (timers[id]) {
          t.fireAt += t.interval;
          if (t.fireAt <= logicalTime) {
            /* ficou para trás: realinha sem rajada */
            t.fireAt = logicalTime + t.interval;
          }
        }
      } else {
        delete timers[id];
        timerCount--;
        if (timerCount < MAX_TIMERS) limitWarned = false;
        try { t.cb(); } catch (e) { reportError(e); }
      }
    }
  }

  function clear() {
    timers = Object.create(null);
    timerCount = 0;
    limitWarned = false;
  }

  function now() { return logicalTime; }

  F.timers = {
    schedule: schedule,
    scheduleEvery: scheduleEvery,
    cancel: cancel,
    update: update,
    clear: clear,
    now: now
  };
})(window.FPS = window.FPS || {});
