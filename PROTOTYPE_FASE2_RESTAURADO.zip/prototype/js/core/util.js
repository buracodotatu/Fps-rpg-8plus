/* ============================================================
 * util.js - math, RNG, noise, timing helpers.  No dependencies.
 * ============================================================ */
(function (F) {
  'use strict';

  var util = {};

  util.clamp = function (v, a, b) { return v < a ? a : (v > b ? b : v); };
  util.lerp = function (a, b, t) { return a + (b - a) * t; };
  util.smooth = function (t) { return t * t * (3 - 2 * t); };
  util.sign = function (v) { return v < 0 ? -1 : (v > 0 ? 1 : 0); };

  /* wrap angle into (-PI, PI] */
  util.wrapPi = function (a) {
    a = (a + Math.PI) % (Math.PI * 2);
    if (a < 0) a += Math.PI * 2;
    return a - Math.PI;
  };

  /* deterministic PRNG so runs/tests are reproducible */
  util.mulberry32 = function (seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };

  /* integer hash -> [0,1) : used by the value-noise below */
  util.hash2 = function (x, y, seed) {
    var h = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(seed | 0, 1442695041);
    h = (h ^ (h >>> 13)) | 0;
    h = Math.imul(h, 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };

  /* bilinear value noise, period-free, [0,1] */
  util.noise = function (x, y, seed) {
    var xi = Math.floor(x), yi = Math.floor(y);
    var xf = x - xi, yf = y - yi;
    var u = util.smooth(xf), v = util.smooth(yf);
    var a = util.hash2(xi, yi, seed), b = util.hash2(xi + 1, yi, seed);
    var c = util.hash2(xi, yi + 1, seed), d = util.hash2(xi + 1, yi + 1, seed);
    return (a + (b - a) * u) * (1 - v) + (c + (d - c) * u) * v;
  };

  /* fractal brownian motion, [0,1] */
  util.fbm = function (x, y, oct, seed) {
    var sum = 0, amp = 0.5, norm = 0;
    for (var i = 0; i < oct; i++) {
      sum += util.noise(x, y, seed + i * 101) * amp;
      norm += amp;
      x *= 2.03; y *= 2.03; amp *= 0.5;
    }
    return sum / norm;
  };

  /* simple exponential smoothing that is frame-rate independent */
  util.damp = function (cur, target, rate, dt) {
    return cur + (target - cur) * (1 - Math.exp(-rate * dt));
  };

  /* ---- tiny perf probe ---- */
  util.perf = { marks: {}, frames: 0, last: 0, avg: 0, max: 0, _sum: 0, _n: 0 };
  util.begin = function (k) { return performance.now(); };
  util.end = function (k, t0) {
    var d = performance.now() - t0;
    util.perf[k] = util.perf[k] || { avg: 0, max: 0, n: 0 };
    var p = util.perf[k];
    p.avg = p.avg + (d - p.avg) / (++p.n < 60 ? p.n : 60);
    if (d > p.max) p.max = d;
    return d;
  };

  F.util = util;
})(window.FPS = window.FPS || {});