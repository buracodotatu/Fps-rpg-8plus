/* ============================================================
 * textures.js - every texture is generated procedurally at boot
 * into a 64x64 Uint8Array of palette indices.  No image files,
 * no loading, fully deterministic.
 * ============================================================ */
(function (F) {
  'use strict';

  var TEX = 64;
  var P = F.palette, R = P.RAMPS, B = P.BRIGHT;
  var noise = F.util.noise, fbm = F.util.fbm;

  function buf() { return new Uint8Array(TEX * TEX); }
  function each(t, fn) {
    for (var y = 0; y < TEX; y++) for (var x = 0; x < TEX; x++) {
      t[y * TEX + x] = fn(x, y) | 0;
    }
  }
  function px(t, x, y, c) {
    if (x >= 0 && y >= 0 && x < TEX && y < TEX) t[y * TEX + x] = c;
  }
  function rect(t, x0, y0, w, h, c) {
    for (var y = y0; y < y0 + h; y++) for (var x = x0; x < x0 + w; x++) px(t, x, y, c);
  }
  function frameRect(t, x0, y0, w, h, c) {
    for (var i = 0; i < w; i++) { px(t, x0 + i, y0, c); px(t, x0 + i, y0 + h - 1, c); }
    for (var j = 0; j < h; j++) { px(t, x0, y0 + j, c); px(t, x0 + w - 1, y0 + j, c); }
  }

  /* ---------------------------------------------------------- walls */
  function texBrick() {
    var t = buf(), bh = 8, bw = 16, rnd = F.util.mulberry32(7);
    for (var y = 0; y < TEX; y++) {
      var row = (y / bh) | 0;
      var off = (row & 1) * (bw / 2);
      for (var x = 0; x < TEX; x++) {
        var bx = ((x + off) % bw), mortar = (y % bh) < 2 || bx < 2;
        var seed = ((y + off) / bh | 0) * 31 + (((x + off) / bw) | 0);
        var tone = 0.42 + noise(seed, seed * 0.37, 11) * 0.34;
        var g = fbm(x * 0.25, y * 0.25, 3, 21);
        if (mortar) t[y * TEX + x] = R.CONCRETE.i(0.42 + g * 0.18);
        else t[y * TEX + x] = R.BRICK.i(tone * (0.78 + g * 0.42));
      }
    }
    /* grime toward the bottom */
    for (var yy = 44; yy < TEX; yy++) {
      var k = (yy - 44) / 20;
      for (var xx = 0; xx < TEX; xx++) {
        var d = k * (0.5 + noise(xx * 0.2, yy * 0.4, 5) * 0.8);
        if (d > 0.5) t[yy * TEX + xx] = R.BRICK.i(F.util.clamp(0.22 - d * 0.12, 0.02, 0.22));
      }
    }
    return t;
  }

  function texStone() {
    var t = buf();
    each(t, function (x, y) {
      var bw = 32, bh = 16;
      var row = (y / bh) | 0, off = (row & 1) * 16;
      var lx = (x + off) % bw, ly = y % bh;
      var edge = (lx < 1 || ly < 1 || lx > bw - 3 || ly > bh - 3);
      var g = fbm(x * 0.18, y * 0.18, 4, 33);
      var v = 0.45 + g * 0.45;
      if (edge) v -= 0.22;
      /* bevel highlight top-left */
      if (ly === 2 && lx > 2 && lx < bw - 3) v += 0.14;
      return R.STONE.i(v);
    });
    return t;
  }

  function texTech() {
    var t = buf();
    each(t, function (x, y) {
      var g = fbm(x * 0.4, y * 0.4, 3, 44);
      var v = 0.40 + g * 0.22;
      /* recessed centre band */
      if (y > 18 && y < 46 && x > 6 && x < 58) v = 0.24 + g * 0.14;
      /* bright horizontal rails */
      if (y === 18 || y === 46 || x === 6 || x === 58) v = 0.92;
      if (y === 19 || y === 47) v = 0.6;
      return R.TECH.i(v);
    });
    /* rivets */
    for (var i = 0; i < 4; i++) {
      var cx = [3, 60, 3, 60][i], cy = [3, 3, 60, 60][i];
      for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++)
        px(t, cx + dx, cy + dy, dx === -1 || dy === -1 ? R.STEEL.i(0.95) : R.STEEL.i(0.35));
    }
    /* hazard stripe */
    for (var y2 = 52; y2 < 58; y2++) for (var x2 = 8; x2 < 56; x2++)
      t[y2 * TEX + x2] = (((x2 + y2) / 4 | 0) & 1) ? R.DEMON2.i(0.95) : R.BLACK.i(0.05);
    return t;
  }

  function texComputer() {
    var t = buf();
    each(t, function (x, y) {
      var g = fbm(x * 0.5, y * 0.5, 2, 77);
      return R.BLACK.i(0.28 + g * 0.2);
    });
    /* server racks: columns of blinking lights */
    for (var col = 0; col < 4; col++) {
      var x0 = 4 + col * 16;
      rect(t, x0, 6, 12, 52, R.STEEL.i(0.22 + noise(col, 3, 9) * 0.1));
      frameRect(t, x0, 6, 12, 52, R.STEEL.i(0.62));
      for (var r = 0; r < 9; r++) {
        var on = noise(col * 7 + r, r * 3, 13) > 0.45;
        var yy = 10 + r * 5;
        rect(t, x0 + 2, yy, 3, 2, on ? (r % 3 === 0 ? B.GREEN : B.AMBER) : R.BLACK.i(0.05));
        rect(t, x0 + 7, yy, 3, 2, on && noise(r, col, 31) > 0.6 ? B.CYAN : R.BLACK.i(0.05));
      }
    }
    /* big screen */
    rect(t, 20, 24, 24, 14, R.GLASS.i(0.55));
    for (var sy = 0; sy < 14; sy++) for (var sx = 0; sx < 24; sx++)
      if (noise(sx * 0.6, sy * 0.6 + 4, 51) > 0.62) px(t, 20 + sx, 24 + sy, B.CYAN);
    frameRect(t, 20, 24, 24, 14, R.STEEL.i(0.8));
    return t;
  }

  function texMoss() {
    var t = texStone();
    for (var y = 0; y < TEX; y++) for (var x = 0; x < TEX; x++) {
      var m = fbm(x * 0.11, y * 0.09, 4, 88);
      if (m > 0.56) t[y * TEX + x] = R.MOSS.i(0.3 + (m - 0.56) * 1.4);
      else if (m > 0.5) t[y * TEX + x] = R.MOSS.i(0.22);
    }
    return t;
  }

  function texWood() {
    var t = buf();
    each(t, function (x, y) {
      var plank = (y / 16) | 0;
      var grain = fbm(x * 0.06 + plank * 5, y * 0.5, 3, 61);
      var v = 0.34 + grain * 0.42;
      if (y % 16 < 1) v = 0.1;
      if (y % 16 === 1) v = 0.62;
      if ((x + plank * 23) % 32 < 1) v *= 0.5;
      return R.WOOD.i(v);
    });
    return t;
  }

  function texCrate() {
    var t = texWood();
    frameRect(t, 0, 0, TEX, TEX, R.STEEL.i(0.5));
    frameRect(t, 2, 2, 60, 60, R.STEEL.i(0.28));
    /* diagonal braces */
    for (var i = 0; i < 64; i++) {
      px(t, i, i, R.WOOD.i(0.72)); px(t, i, i + 1, R.WOOD.i(0.2));
      px(t, 63 - i, i, R.WOOD.i(0.72)); px(t, 63 - i, i + 1, R.WOOD.i(0.2));
    }
    for (var c = 0; c < 4; c++) {
      var cx = [4, 58, 4, 58][c], cy = [4, 4, 58, 58][c];
      rect(t, cx - 2, cy - 2, 5, 5, R.STEEL.i(0.6));
      px(t, cx, cy, R.STEEL.i(0.9));
    }
    return t;
  }

  function texSteel() {
    var t = buf();
    each(t, function (x, y) {
      var brush = noise(x * 2.0, y * 0.15, 71);
      var v = 0.34 + brush * 0.22 + fbm(x * 0.1, y * 0.1, 2, 91) * 0.12;
      if (x < 3 || y < 3 || x > 60 || y > 60) v = 0.14;
      if (x === 3 || y === 3) v = 0.7;
      return R.STEEL.i(v);
    });
    for (var i = 0; i < 8; i++) {
      var rx = 8 + i * 7;
      px(t, rx, 8, R.STEEL.i(0.95)); px(t, rx + 1, 8, R.STEEL.i(0.8)); px(t, rx, 9, R.STEEL.i(0.2));
      px(t, rx, 55, R.STEEL.i(0.95)); px(t, rx + 1, 55, R.STEEL.i(0.8)); px(t, rx, 56, R.STEEL.i(0.2));
    }
    return t;
  }

  function texDoor(locked) {
    var t = buf();
    each(t, function (x, y) {
      var v = 0.3 + fbm(x * 0.2, y * 0.2, 3, 131) * 0.2;
      if (x === 31 || x === 32) v = 0.06;          /* centre seam      */
      if (x < 2 || x > 61) v = 0.1;
      if (x === 2 || x === 61) v = 0.75;
      return R.STEEL.i(v);
    });
    /* panel relief */
    frameRect(t, 6, 6, 22, 24, R.STEEL.i(0.62));
    frameRect(t, 36, 6, 22, 24, R.STEEL.i(0.62));
    frameRect(t, 6, 34, 22, 24, R.STEEL.i(0.62));
    frameRect(t, 36, 34, 22, 24, R.STEEL.i(0.62));
    /* handle */
    rect(t, 24, 30, 5, 3, R.STEEL.i(0.95));
    rect(t, 35, 30, 5, 3, R.STEEL.i(0.95));
    /* hazard foot */
    for (var y = 56; y < 62; y++) for (var x = 4; x < 60; x++)
      t[y * TEX + x] = (((x + y) / 4 | 0) & 1) ? R.DEMON2.i(0.9) : R.BLACK.i(0.06);
    if (locked) {
      rect(t, 28, 14, 8, 12, R.BLOOD.i(0.55));
      frameRect(t, 28, 14, 8, 12, B.RED);
      rect(t, 30, 17, 4, 6, B.AMBER);
      for (var k = 0; k < 3; k++) px(t, 30 + k, 12, B.RED);
    } else {
      rect(t, 28, 16, 8, 8, R.TECH.i(0.3));
      frameRect(t, 28, 16, 8, 8, R.STEEL.i(0.9));
      px(t, 31, 20, B.GREEN); px(t, 32, 20, B.GREEN);
    }
    return t;
  }

  function texExit() {
    var t = buf();
    each(t, function (x, y) {
      return R.STEEL.i(0.2 + fbm(x * 0.2, y * 0.2, 2, 151) * 0.15);
    });
    /* glowing portal rectangle */
    for (var y = 8; y < 56; y++) for (var x = 12; x < 52; x++) {
      var dx = Math.min(x - 12, 51 - x), dy = Math.min(y - 8, 55 - y);
      var d = Math.min(dx, dy);
      var pulse = 0.55 + 0.45 * Math.sin((x + y) * 0.35);
      t[y * TEX + x] = d < 2 ? B.WHITE : (pulse > 0.6 ? B.LIME : B.GREEN);
    }
    frameRect(t, 10, 6, 44, 52, R.STEEL.i(0.85));
    /* upward chevrons */
    for (var i = 0; i < 6; i++) {
      var cy = 22 + i * 5;
      for (var j = 0; j < 10; j++) {
        px(t, 27 + j, cy - (5 - Math.abs(j - 5)), B.WHITE);
      }
    }
    return t;
  }

  function texRock() {
    var t = buf();
    each(t, function (x, y) {
      var n = fbm(x * 0.09, y * 0.09, 5, 171);
      var n2 = fbm(x * 0.35, y * 0.35, 2, 181);
      var v = 0.25 + n * 0.6 + n2 * 0.12;
      if (n < 0.34) v = 0.12;
      return (n > 0.62 && n2 > 0.6) ? R.MOSS.i(0.4) : R.STONE.i(v);
    });
    return t;
  }

  function texFoliage() {
    var t = buf();
    each(t, function (x, y) {
      var n = fbm(x * 0.14, y * 0.14, 4, 191);
      var v = 0.2 + n * 0.75;
      return R.GRASS.i(v);
    });
    /* trunk */
    for (var y = 34; y < 64; y++) for (var x = 26; x < 38; x++) {
      var g = fbm(x * 0.3, y * 0.12, 3, 201);
      t[y * TEX + x] = R.WOOD.i(0.22 + g * 0.3);
    }
    return t;
  }

  function texFence() {
    var t = buf();
    each(t, function (x, y) {
      var post = (x % 32) < 4;
      var rail = (y % 20) < 3;
      if (post) return R.WOOD.i(0.3 + noise(y * 0.4, x, 211) * 0.3);
      if (rail) return R.WOOD.i(0.34 + noise(x * 0.3, y, 221) * 0.28);
      /* slats */
      var slat = (x % 8) < 5;
      return slat ? R.WOOD.i(0.2 + noise(x * 0.8, y * 0.2, 231) * 0.34) : R.WOOD.i(0.08);
    });
    return t;
  }

  /* ---------------------------------------------------------- ground */
  function texAsphalt() {
    var t = buf();
    each(t, function (x, y) {
      var spk = fbm(x * 0.7, y * 0.7, 3, 241);
      var v = 0.24 + spk * 0.5;
      if (noise(x * 0.06, y * 0.06, 251) > 0.72 && (x + y * 2) % 17 < 2) v = 0.08; /* crack */
      if (x % 32 === 0 || y % 32 === 0) v *= 0.72;                                  /* seams  */
      return R.CONCRETE.i(v);
    });
    return t;
  }

  function texGrate() {
    var t = buf();
    each(t, function (x, y) {
      var bar = (x % 8) < 3 || (y % 8) < 3;
      return bar ? R.STEEL.i(0.42 + noise(x, y * 3, 261) * 0.25) : R.BLACK.i(0.05);
    });
    frameRect(t, 0, 0, 64, 64, R.STEEL.i(0.7));
    return t;
  }

  function texGrass() {
    var t = buf();
    each(t, function (x, y) {
      var n = fbm(x * 0.22, y * 0.22, 4, 271);
      var d = fbm(x * 0.05, y * 0.05, 3, 281);
      if (d > 0.62) return R.SAND.i(0.4 + n * 0.35);
      return R.GRASS.i(0.22 + n * 0.7);
    });
    return t;
  }

  function texCeiling() {
    var t = buf();
    each(t, function (x, y) {
      var panel = (x % 32) < 1 || (y % 32) < 1;
      var v = 0.16 + fbm(x * 0.3, y * 0.3, 3, 291) * 0.18;
      if (panel) v = 0.05;
      /* lamp tiles */
      var lx = x % 32, ly = y % 32;
      if (lx > 10 && lx < 22 && ly > 10 && ly < 22) {
        var on = ((x / 32 | 0) + (y / 32 | 0)) % 3 !== 0;
        return on ? (noise(x, y, 301) > 0.5 ? B.HOTWHT : B.AMBER) : R.BLACK.i(0.08);
      }
      return R.CONCRETE.i(v);
    });
    return t;
  }

  /* ---------------------------------------------------------- sky */
  function texSky() {
    var t = buf();
    for (var y = 0; y < TEX; y++) {
      var e = 1 - y / (TEX - 1);              /* 0 at horizon, 1 at zenith */
      for (var x = 0; x < TEX; x++) {
        var band = Math.pow(e, 0.8);
        var r = 150 + (36 - 150) * band, g = 178 + (58 - 178) * band, b = 205 + (120 - 205) * band;
        /* clouds */
        var c = fbm(x * 0.09 + 4, y * 0.16 + 2, 4, 311);
        var cover = Math.max(0, c - (0.5 + band * 0.22)) * 3.2;
        r += (250 - r) * cover; g += (252 - g) * cover; b += (255 - b) * cover;
        /* sun disc at u ~ 0.18 */
        var sxp = (x - 11.5), syp = (y - 12);
        var sd = Math.sqrt(sxp * sxp + syp * syp);
        if (sd < 5.5) { r = 255; g = 250; b = 210; }
        else if (sd < 10) { var gl = (10 - sd) / 4.5; r = r + (255 - r) * gl; g = g + (240 - g) * gl; b = b + (190 - b) * gl; }
        /* push into the palette through the ice/glass ramps for a smooth ramp */
        t[y * TEX + x] = skyIndex(r, g, b);
      }
    }
    return t;
  }

  /* sky needs smoother gradients than the 8-step ramps give, so quantise
     into the nearest existing palette entry.  Only 64x64 pixels exist, so
     a memoised nearest-neighbour search is cheap. */
  var SKY_CACHE = new Int32Array(64 * 64 * 64).fill(-1);
  function skyIndex(r, g, b) {
    var key = ((r >> 2) << 12) | ((g >> 2) << 6) | (b >> 2);
    var hit = SKY_CACHE[key];
    if (hit >= 0) return hit;
    var R0 = (r >> 2) << 2, G0 = (g >> 2) << 2, B0 = (b >> 2) << 2;
    var best = 1, bd = 1e9;
    for (var c = 1; c < P.BRIGHT_BASE; c++) {
      var col = P.rgb(c);
      var dr = col[0] - R0, dg = col[1] - G0, db = col[2] - B0;
      var d = dr * dr * 0.9 + dg * dg * 1.2 + db * db * 0.7;
      if (d < bd) { bd = d; best = c; }
    }
    SKY_CACHE[key] = best;
    return best;
  }

  /* ---------------------------------------------------------- registry */
  var list = [];
  function reg(name, data, opts) {
    list.push({ name: name, data: data, solid: !!(opts && opts.solid), sky: !!(opts && opts.sky) });
    return list.length - 1;
  }

  var T = {};
  T.BRICK     = reg('brick', texBrick());
  T.STONE     = reg('stone', texStone());
  T.TECH      = reg('tech', texTech());
  T.COMPUTER  = reg('computer', texComputer());
  T.MOSS      = reg('moss', texMoss());
  T.WOOD      = reg('wood', texWood());
  T.CRATE     = reg('crate', texCrate());
  T.STEEL     = reg('steel', texSteel());
  T.DOOR      = reg('door', texDoor(false));
  T.DOOR_LOCK = reg('door_locked', texDoor(true));
  T.EXIT      = reg('exit', texExit());
  T.ROCK      = reg('rock', texRock());
  T.FOLIAGE   = reg('foliage', texFoliage());
  T.FENCE     = reg('fence', texFence());
  T.ASPHALT   = reg('asphalt', texAsphalt());
  T.GRATE     = reg('grate', texGrate());
  T.GRASS     = reg('grass', texGrass());
  T.CEILING   = reg('ceiling', texCeiling());
  T.SKY       = reg('sky', texSky(), { sky: true });

  F.textures = {
    SIZE: TEX, list: list, id: T,
    get: function (i) { return list[i] || list[0]; },
    /* used by the HUD to show a texture swatch */
    toRGBA: function (i, out) {
      var src = list[i].data, pal = P.PALETTE;
      for (var k = 0; k < src.length; k++) out[k] = pal[src[k]];
      return out;
    }
  };
})(window.FPS = window.FPS || {});