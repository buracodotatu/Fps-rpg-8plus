/* ============================================================
 * palette.js - 256-colour palette + pre-shaded LUTs.
 *
 * Every texture / sprite is stored as a Uint8Array of *palette
 * indices*.  Distance fog, wall darkening, pain flashes etc. are
 * then a single table lookup per pixel:
 *     buf[ofs] = SHADE[shade * 256 + texel]
 * That is what keeps a software raycaster at 60fps in JS.
 * ============================================================ */
(function (F) {
  'use strict';

  var cols = [];
  function push(r, g, b) {
    cols.push([Math.max(0, Math.min(255, r | 0)),
               Math.max(0, Math.min(255, g | 0)),
               Math.max(0, Math.min(255, b | 0))]);
    return cols.length - 1;
  }

  /* transparent / index 0 must stay empty */
  push(0, 0, 0);

  var RAMPS = {};
  function ramp(name, rgb, n, dark, light) {
    var base = cols.length;
    for (var i = 0; i < n; i++) {
      var t = n === 1 ? 1 : i / (n - 1);
      var m = dark + (light - dark) * t;
      push(rgb[0] * m, rgb[1] * m, rgb[2] * m);
    }
    RAMPS[name] = {
      base: base, n: n,
      /* t in [0,1] -> palette index inside this ramp */
      i: function (t) {
        t = t < 0 ? 0 : (t > 1 ? 1 : t);
        return base + (t * (n - 1) + 0.5 | 0);
      },
      /* absolute index of the darkest / lightest step */
      get dark() { return base; },
      get light() { return base + n - 1; }
    };
  }

  var N = 8;
  ramp('BLACK',    [ 22,  24,  28], N, 0.00, 0.55);
  ramp('STONE',    [150, 152, 160], N, 0.22, 1.18);
  ramp('CONCRETE', [108, 110, 116], N, 0.20, 1.10);
  ramp('BRICK',    [146,  62,  46], N, 0.22, 1.15);
  ramp('TECH',     [ 96, 122, 152], N, 0.18, 1.15);
  ramp('STEEL',    [132, 142, 156], N, 0.16, 1.22);
  ramp('MOSS',     [ 92, 128,  70], N, 0.20, 1.15);
  ramp('GRASS',    [ 74, 112,  54], N, 0.24, 1.25);
  ramp('SAND',     [168, 152, 108], N, 0.28, 1.15);
  ramp('WOOD',     [124,  88,  52], N, 0.22, 1.15);
  ramp('CRATE',    [158, 126,  72], N, 0.24, 1.12);
  ramp('RUST',     [148,  86,  40], N, 0.22, 1.12);
  ramp('DEMON',    [178,  56,  42], N, 0.20, 1.10);
  ramp('DEMON2',   [216, 124,  58], N, 0.25, 1.05);
  ramp('FLESH',    [198, 142, 122], N, 0.24, 1.05);
  ramp('BLOOD',    [154,  12,  22], N, 0.20, 1.10);
  ramp('SKIN',     [204, 164, 124], N, 0.28, 1.02);
  ramp('UNIFORM',  [ 72,  94,  62], N, 0.22, 1.15);
  ramp('PURPLE',   [112,  72, 152], N, 0.22, 1.15);
  ramp('BONE',     [222, 216, 192], N, 0.30, 1.00);
  ramp('GLASS',    [ 62,  92, 124], N, 0.25, 1.30);
  ramp('ICE',      [150, 190, 220], N, 0.30, 1.05);

  /* ---- reserved: indices >= BRIGHT_BASE ignore all shading ---- */
  var BRIGHT_BASE = 240;
  while (cols.length < BRIGHT_BASE) push(0, 0, 0);

  var BRIGHT = {};
  function bright(name, r, g, b) { BRIGHT[name] = push(r, g, b); }
  bright('WHITE',   255, 255, 255);
  bright('YELLOW',  255, 232,  90);
  bright('ORANGE',  255, 150,  40);
  bright('RED',     255,  56,  40);
  bright('CYAN',     90, 240, 255);
  bright('LIME',    140, 255, 110);
  bright('MAGENTA', 255,  90, 240);
  bright('PLASMA',  180, 255, 220);
  bright('EMBER',   255, 200, 120);
  bright('SKYGLOW', 200, 226, 255);
  bright('AMBER',   255, 190,  60);
  bright('HOTWHT',  255, 250, 220);
  bright('GREEN',    70, 255, 120);
  bright('BLUE',     80, 140, 255);
  bright('PINK',    255, 160, 190);
  bright('GREY',    190, 190, 190);
  while (cols.length < 256) push(255, 0, 255); /* debug magenta */

  /* ---------------- pack to Uint32 ----------------
     ImageData stores bytes as R,G,B,A in memory.  Read back through a
     Uint32Array that is A<<24 | B<<16 | G<<8 | R on a little-endian
     machine (i.e. practically every machine), so red and blue have to
     be swapped here - otherwise the whole game renders with its
     channels reversed and the sky comes out brown. */
  var LITTLE_ENDIAN = (function () {
    var b = new ArrayBuffer(4);
    new Uint32Array(b)[0] = 0x11223344;
    return new Uint8Array(b)[0] === 0x44;
  })();

  function pack(r, g, b, a) {
    a = (a === undefined ? 255 : a) | 0;
    r = r | 0; g = g | 0; b = b | 0;
    return (LITTLE_ENDIAN
      ? ((a << 24) | (b << 16) | (g << 8) | r)
      : ((r << 24) | (g << 16) | (b << 8) | a)) >>> 0;
  }

  var PALETTE = new Uint32Array(256);
  for (var i = 0; i < 256; i++) PALETTE[i] = pack(cols[i][0], cols[i][1], cols[i][2]);

  /* ---------------- shading LUT ---------------- */
  var SHADES = 24;              /* fog levels 0..23, 0 = full bright   */
  var SHADE_PAIN = SHADES;      /* +0 : enemy hit flash                */
  var SHADE_WHITE = SHADES + 1; /* +1 : spawn / explosion flash         */
  var FOG = [10, 12, 22];
  var SHADE = new Uint32Array((SHADES + 2) * 256);

  for (var s = 0; s < SHADES; s++) {
    var t = s / (SHADES - 1);
    var f = Math.pow(1 - t, 1.25) * 0.99 + 0.01;
    for (var c = 0; c < 256; c++) {
      var col = cols[c];
      var r = Math.min(255, col[0] * f + FOG[0] * (1 - f));
      var g = Math.min(255, col[1] * f + FOG[1] * (1 - f));
      var b = Math.min(255, col[2] * f + FOG[2] * (1 - f));
      SHADE[s * 256 + c] = pack(r, g, b);
    }
  }
  /* pain / flash rows keep luminance but remap hue */
  for (var c2 = 0; c2 < 256; c2++) {
    var q = cols[c2];
    var lum = (q[0] * 0.30 + q[1] * 0.59 + q[2] * 0.11);
    var pr = Math.min(255, 110 + lum * 0.95);
    SHADE[SHADE_PAIN * 256 + c2] = pack(pr, lum * 0.16, lum * 0.12);
    var pw = Math.min(255, 90 + lum * 1.05);
    SHADE[SHADE_WHITE * 256 + c2] = pack(pw, pw, pw);
  }

  /* distance -> shade level.  FOG_START px of "clear" view then ramp out */
  var FOG_MAX_DIST = 19.0;
  function shadeForDist(d) {
    var t = d / FOG_MAX_DIST;
    if (t < 0) t = 0;
    if (t > 1) t = 1;
    return (Math.pow(t, 1.35) * (SHADES - 1) + 0.5) | 0;
  }

  F.palette = {
    PALETTE: PALETTE, SHADE: SHADE, SHADES: SHADES,
    SHADE_PAIN: SHADE_PAIN, SHADE_WHITE: SHADE_WHITE,
    BRIGHT_BASE: BRIGHT_BASE,
    RAMPS: RAMPS, BRIGHT: BRIGHT,
    shadeForDist: shadeForDist,
    pack: pack,
    littleEndian: LITTLE_ENDIAN,
    rgb: function (idx) { return cols[idx]; },
    count: function () { return cols.length; }
  };
})(window.FPS = window.FPS || {});
