/* ============================================================
 * events.js - serviço de eventos (pub/sub).
 *
 * Fase 2 (serviços fundamentais). Independente de diagnostics,
 * timers, state e do motor gráfico. Sem DOM, sem console.
 *
 * CORREÇÃO (auditoria Fase 2):
 *   - subscriptions e byId usam Object.create(null) para não
 *     colidir com propriedades herdadas de Object.prototype.
 *   - nomes de evento como '__proto__', 'constructor' e
 *     'toString' passam a funcionar como qualquer outro.
 *
 *   on(nome, cb)   -> id de inscrição (reusa o id se o mesmo
 *                     par nome+cb já estiver inscrito)
 *   off(id)        -> remove inscrição
 *   emit(nome, p)  -> dispara para todos os ouvintes; erros
 *                     isolados por callback; retorna quantos
 *                     ouviram
 *   clear()        -> limpa tudo
 *
 * Não cria timers nem requestAnimationFrame.
 * Não gera mensagens no console por quadro.
 * ============================================================ */
(function (F) {
  'use strict';

  /* Object.create(null) => sem cadeia de protótipo; qualquer
     string vira chave própria sem riscos de colisão. */
  var subscriptions = Object.create(null);
  var byId = Object.create(null);
  var nextId = 1;

  function isFn(x) { return typeof x === 'function'; }
  function isName(x) { return typeof x === 'string' && x.length > 0; }

  function on(name, cb) {
    if (!isName(name) || !isFn(cb)) return null;
    var map = subscriptions[name];
    if (!map) { map = subscriptions[name] = new Map(); }
    var existing = map.get(cb);
    if (existing) return existing;
    var id = nextId++;
    map.set(cb, id);
    byId[id] = { name: name, cb: cb };
    return id;
  }

  function off(id) {
    var entry = byId[id];
    if (!entry) return false;
    var map = subscriptions[entry.name];
    if (map) {
      map.delete(entry.cb);
      if (map.size === 0) delete subscriptions[entry.name];
    }
    delete byId[id];
    return true;
  }

  function emit(name, payload) {
    var map = subscriptions[name];
    if (!map || map.size === 0) return 0;
    /* snapshot para permitir on/off dentro do próprio emit */
    var snapshot = [];
    map.forEach(function (subId, cbFn) { snapshot.push(subId, cbFn); });
    var fired = 0;
    for (var i = 0; i < snapshot.length; i += 2) {
      var id = snapshot[i], cb = snapshot[i + 1];
      if (!byId[id]) continue;          /* removido durante o emit */
      try { cb(payload); fired++; }
      catch (e) {
        if (F.diagnostics && F.diagnostics.record) {
          F.diagnostics.record('events:' + name, e);
        }
      }
    }
    return fired;
  }

  function clear() {
    subscriptions = Object.create(null);
    byId = Object.create(null);
  }

  F.events = {
    on: on, off: off, emit: emit, clear: clear
  };
})(window.FPS = window.FPS || {});
