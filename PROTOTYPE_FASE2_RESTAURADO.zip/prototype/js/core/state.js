/* ============================================================
 * state.js - máquina de estados de tela e sessão.
 *
 * Fase 2 (serviços fundamentais). Não substitui FPS.player,
 * não contém atributos / XP / classes / inventário. Apenas
 * controla qual "tela" está ativa e guarda um objeto de sessão
 * genérico.
 *
 * (Correção Fase 2: nenhuma alteração. Auditoria não apontou
 * problemas em state.js — usa array + posições numéricas, não
 * objeto chaveado por string arbitrária.)
 *
 * Transições permitidas (from -> [to...]):
 *   boot      -> menu, playing
 *   menu      -> playing, boot
 *   playing   -> paused, inventory, dialogue, gameover, menu
 *   paused    -> playing, menu, gameover
 *   inventory -> playing
 *   dialogue  -> playing
 *   gameover  -> menu, playing
 *
 * Integração futura: main.js chamará FPS.state.request('playing')
 * ao iniciar o jogo e 'menu'/'gameover' conforme a lógica de RPG
 * for definida em fases posteriores.
 *
 * Requisição aninhada (listener que chama request() durante a
 * notificação) é rejeitada e registrada como warning em
 * diagnostics, para manter a máquina previsível.
 * ============================================================ */
(function (F) {
  'use strict';

  var STATES = ['boot', 'menu', 'playing', 'paused', 'inventory', 'dialogue', 'gameover'];

  var TRANSITIONS = {
    boot:      ['menu', 'playing'],
    menu:      ['playing', 'boot'],
    playing:   ['paused', 'inventory', 'dialogue', 'gameover', 'menu'],
    paused:    ['playing', 'menu', 'gameover'],
    inventory: ['playing'],
    dialogue:  ['playing'],
    gameover:  ['menu', 'playing']
  };

  var current = 'boot';
  var session = {};
  var listeners = [];
  var notifying = false;

  function get() { return current; }
  function is(s) { return current === s; }

  function canTransition(from, to) {
    if (STATES.indexOf(from) < 0) return false;
    if (STATES.indexOf(to) < 0) return false;
    if (from === to) return true;
    var list = TRANSITIONS[from];
    return !!(list && list.indexOf(to) >= 0);
  }

  function request(target) {
    if (STATES.indexOf(target) < 0) return false;
    if (target === current) return true;
    if (!canTransition(current, target)) return false;
    if (notifying) {
      if (F.diagnostics && F.diagnostics.warn) {
        F.diagnostics.warn('state:nested-request', { target: target, current: current });
      }
      return false;
    }
    var prev = current;
    current = target;
    notifying = true;
    for (var i = 0; i < listeners.length; i++) {
      var cb = listeners[i];
      if (!cb) continue;
      try { cb(target, prev); }
      catch (e) {
        if (F.diagnostics && F.diagnostics.record) {
          F.diagnostics.record('state:listener', e);
        }
      }
    }
    notifying = false;
    return true;
  }

  function onChange(cb) {
    if (typeof cb !== 'function') return -1;
    listeners.push(cb);
    return listeners.length - 1;
  }

  function offChange(idx) {
    if (idx < 0 || idx >= listeners.length) return false;
    listeners[idx] = null;
    return true;
  }

  function reset() { current = 'boot'; }

  function getSession() { return session; }

  function updateSession(patch) {
    if (!patch || typeof patch !== 'object') return session;
    for (var k in patch) {
      if (Object.prototype.hasOwnProperty.call(patch, k)) session[k] = patch[k];
    }
    return session;
  }

  function resetSession() {
    for (var k in session) {
      if (Object.prototype.hasOwnProperty.call(session, k)) delete session[k];
    }
    return session;
  }

  F.state = {
    STATES: STATES,
    get: get,
    is: is,
    canTransition: canTransition,
    request: request,
    onChange: onChange,
    offChange: offChange,
    reset: reset,
    getSession: getSession,
    updateSession: updateSession,
    resetSession: resetSession
  };
})(window.FPS = window.FPS || {});
